package pt.notafalada;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import pt.notafalada.XlsxWriter.Cell;
import pt.notafalada.XlsxWriter.Sheet;

/**
 * Livro Excel: Resumo, uma folha por turma (elementos agrupados por matéria, média por matéria,
 * matérias atingidas e nível de Atividades Físicas no 1.º e 2.º semestre), Registo e Critérios.
 */
public class ExcelExport {

    public static final double LIMIAR_PADRAO = 3.0;
    private static final String LIMIAR = "'Critérios'!$B$3";

    public static void write(Store st, OutputStream out) throws IOException {
        Locale pt = new Locale("pt", "PT");
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm", pt);
        XlsxWriter x = new XlsxWriter();
        List<Store.Turma> turmas = st.turmasOrdenadas();

        // ---------- Resumo ----------
        Sheet res = x.addSheet("Resumo");
        res.row().add(Cell.t("Avaliação de Educação Física", XlsxWriter.S_TITULO));
        res.row().add(Cell.t("Exportado em " + df.format(new Date()), XlsxWriter.S_NORMAL));
        res.row();
        List<Cell> h = res.row();
        for (String s : new String[]{"Ano", "Turma", "Alunos", "Notas registadas", "Matérias avaliadas", "Média geral"})
            h.add(Cell.t(s, XlsxWriter.S_CAB));
        res.widths.add(9.0); res.widths.add(10.0); res.widths.add(10.0); res.widths.add(17.0);
        res.widths.add(40.0); res.widths.add(13.0);
        res.freezeRows = 4;

        // ---------- Folha por turma ----------
        for (Store.Turma t : turmas) {
            List<Store.Materia> mats = materiasDaTurma(st, t);
            Sheet sh = x.addSheet(t.label().isEmpty() ? "Turma" : t.label());
            sh.row().add(Cell.t("Turma " + t.label() + " — escala 1 a 5 (ver «Critérios»)", XlsxWriter.S_TITULO));
            List<Cell> r2 = sh.row();
            List<Cell> r3 = sh.row();
            r2.add(Cell.t("Nº", XlsxWriter.S_CAB)); r3.add(Cell.empty(XlsxWriter.S_CAB));
            r2.add(Cell.t("Aluno", XlsxWriter.S_CAB)); r3.add(Cell.empty(XlsxWriter.S_CAB));
            sh.merges.add("A2:A3");
            sh.merges.add("B2:B3");
            sh.widths.add(5.0); sh.widths.add(26.0);

            int col = 2;
            List<int[]> grupos = new ArrayList<>(); // {primeira coluna, última coluna de elementos, coluna da média}
            for (Store.Materia m : mats) {
                int ini = col;
                for (int k = 0; k < m.elementos.size(); k++) {
                    r2.add(k == 0 ? Cell.t(m.nome + (m.area.isEmpty() ? "" : " (" + m.area + ")"), XlsxWriter.S_CAB)
                            : Cell.empty(XlsxWriter.S_CAB));
                    r3.add(Cell.t(m.elementos.get(k), XlsxWriter.S_CAB));
                    sh.widths.add(Math.max(12.5, Math.min(18.0, m.elementos.get(k).length() * 0.6)));
                    col++;
                }
                r2.add(m.elementos.isEmpty() ? Cell.t(m.nome, XlsxWriter.S_CAB) : Cell.empty(XlsxWriter.S_CAB));
                r3.add(Cell.t("Média", XlsxWriter.S_CAB));
                sh.widths.add(9.0);
                int media = col++;
                sh.merges.add(XlsxWriter.col(ini) + "2:" + XlsxWriter.col(media) + "2");
                grupos.add(new int[]{ini, media - 1, media});
            }
            int cAting = col++, cN1 = col++, cN2 = col++, cJG = col;
            r2.add(Cell.t("Matérias atingidas", XlsxWriter.S_CAB)); r3.add(Cell.t("média ≥ limiar", XlsxWriter.S_CAB));
            r2.add(Cell.t("Nível AF", XlsxWriter.S_CAB)); r3.add(Cell.t("1.º semestre", XlsxWriter.S_CAB));
            r2.add(Cell.empty(XlsxWriter.S_CAB)); r3.add(Cell.t("2.º semestre", XlsxWriter.S_CAB));
            r2.add(Cell.t("1 JDC + 1 GIN", XlsxWriter.S_CAB)); r3.add(Cell.t("atingidos?", XlsxWriter.S_CAB));
            sh.merges.add(XlsxWriter.col(cN1) + "2:" + XlsxWriter.col(cN2) + "2");
            sh.widths.add(12.0); sh.widths.add(11.0); sh.widths.add(11.0); sh.widths.add(12.0);
            sh.freezeRows = 3; sh.freezeCols = 2;

            List<String> alunos = new ArrayList<>(t.alunos);
            for (Store.Nota n : st.notas)
                if (n.turmaId.equals(t.id) && !alunos.contains(n.aluno)) alunos.add(n.aluno);

            double somaGeral = 0; int nGeral = 0, nNotas = 0;
            for (int i = 0; i < alunos.size(); i++) {
                String a = alunos.get(i);
                int linha = 4 + i;
                List<Cell> row = sh.row();
                row.add(Cell.n(i + 1, XlsxWriter.S_CENTRO));
                row.add(Cell.t(a, XlsxWriter.S_TEXTO));
                int ating = 0; boolean jdc = false, gin = false;
                StringBuilder fAting = new StringBuilder();
                StringBuilder fJdc = new StringBuilder(), fGin = new StringBuilder();
                for (int g = 0; g < mats.size(); g++) {
                    Store.Materia m = mats.get(g);
                    double soma = 0; int k = 0;
                    for (String e : m.elementos) {
                        Store.Nota n = st.nota(t.id, a, m.nome, e);
                        if (n == null) row.add(Cell.empty(XlsxWriter.S_TEXTO));
                        else {
                            row.add(Cell.n(n.valor, XlsxWriter.S_N1 + n.valor - 1));
                            soma += n.valor; k++; nNotas++;
                            somaGeral += n.valor; nGeral++;
                        }
                    }
                    int[] gr = grupos.get(g);
                    String mc = XlsxWriter.col(gr[2]) + linha;
                    Double media = k > 0 ? soma / k : null;
                    String fm = m.elementos.isEmpty() ? "\"\""
                            : "IFERROR(AVERAGE(" + XlsxWriter.col(gr[0]) + linha + ":" + XlsxWriter.col(gr[1]) + linha + "),\"\")";
                    row.add(Cell.f(fm, media, XlsxWriter.S_MEDIA));
                    String termo = "IF(ISNUMBER(" + mc + "),IF(" + mc + ">=" + LIMIAR + ",1,0),0)";
                    if (fAting.length() > 0) fAting.append("+");
                    fAting.append(termo);
                    boolean ok = media != null && media >= LIMIAR_PADRAO - 1e-9;
                    if (ok) ating++;
                    if ("JDC".equalsIgnoreCase(m.area)) {
                        if (fJdc.length() > 0) fJdc.append("+");
                        fJdc.append(termo);
                        if (ok) jdc = true;
                    }
                    if ("GIN".equalsIgnoreCase(m.area)) {
                        if (fGin.length() > 0) fGin.append("+");
                        fGin.append(termo);
                        if (ok) gin = true;
                    }
                }
                String ca = XlsxWriter.col(cAting) + linha;
                row.add(Cell.f(fAting.length() == 0 ? "0" : fAting.toString(), (double) ating, XlsxWriter.S_CENTRO));
                row.add(Cell.f("IF(" + ca + ">=7,5,IF(" + ca + ">=5,4,IF(" + ca + ">=4,3,IF(" + ca + ">=3,2,1))))",
                        (double) nivel1(ating), XlsxWriter.S_MEDIA));
                row.add(Cell.f("IF(" + ca + ">=9,5,IF(" + ca + ">=7,4,IF(" + ca + ">=6,3,IF(" + ca + ">=4,2,1))))",
                        (double) nivel2(ating), XlsxWriter.S_MEDIA));
                String fj = "IF(AND((" + (fJdc.length() == 0 ? "0" : fJdc) + ")>=1,(" + (fGin.length() == 0 ? "0" : fGin)
                        + ")>=1),\"Sim\",\"Não\")";
                Cell cj = Cell.f(fj, null, XlsxWriter.S_CENTRO);
                cj.cachedText = jdc && gin ? "Sim" : "Não";
                row.add(cj);
            }

            List<Cell> r = res.row();
            r.add(Cell.t(t.ano == null || t.ano.trim().isEmpty() ? "" : t.ano.trim() + ".º", XlsxWriter.S_CENTRO));
            r.add(Cell.t(t.nome == null ? "" : t.nome, XlsxWriter.S_CENTRO));
            r.add(Cell.n(alunos.size(), XlsxWriter.S_CENTRO));
            r.add(Cell.n(nNotas, XlsxWriter.S_CENTRO));
            StringBuilder nm = new StringBuilder();
            for (Store.Materia m : mats) { if (nm.length() > 0) nm.append(", "); nm.append(m.nome); }
            r.add(Cell.t(nm.toString(), XlsxWriter.S_TEXTO));
            if (nGeral > 0) r.add(Cell.n(Math.round(somaGeral / nGeral * 10) / 10.0, XlsxWriter.S_MEDIA));
            else r.add(Cell.empty(XlsxWriter.S_TEXTO));
        }

        // ---------- Registo ----------
        Sheet reg = x.addSheet("Registo");
        List<Cell> rh = reg.row();
        for (String s : new String[]{"Data", "Ano", "Turma", "Aluno", "Matéria", "Elemento", "Nota", "Descritor"})
            rh.add(Cell.t(s, XlsxWriter.S_CAB));
        reg.widths.add(17.0); reg.widths.add(7.0); reg.widths.add(8.0); reg.widths.add(26.0);
        reg.widths.add(22.0); reg.widths.add(36.0); reg.widths.add(7.0); reg.widths.add(24.0);
        reg.freezeRows = 1;
        List<Store.Nota> todas = new ArrayList<>(st.notas);
        todas.sort((a, b) -> Long.compare(a.data, b.data));
        for (Store.Nota n : todas) {
            Store.Turma t = st.turma(n.turmaId);
            List<Cell> row = reg.row();
            row.add(Cell.t(df.format(new Date(n.data)), XlsxWriter.S_TEXTO));
            row.add(Cell.t(t == null || t.ano == null || t.ano.trim().isEmpty() ? "" : t.ano.trim() + ".º", XlsxWriter.S_CENTRO));
            row.add(Cell.t(t == null ? "" : t.nome, XlsxWriter.S_CENTRO));
            row.add(Cell.t(n.aluno, XlsxWriter.S_TEXTO));
            row.add(Cell.t(n.materia, XlsxWriter.S_TEXTO));
            row.add(Cell.t(n.elemento, XlsxWriter.S_TEXTO));
            row.add(Cell.n(n.valor, XlsxWriter.S_N1 + n.valor - 1));
            row.add(Cell.t(Store.DESCRITORES[n.valor], XlsxWriter.S_TEXTO));
        }

        // ---------- Critérios ----------
        Sheet cr = x.addSheet("Critérios");
        cr.widths.add(34.0); cr.widths.add(26.0); cr.widths.add(14.0);
        cr.row().add(Cell.t("Critérios", XlsxWriter.S_TITULO));
        cr.row();
        List<Cell> lim = cr.row();
        lim.add(Cell.t("Média mínima para a matéria contar como atingida", XlsxWriter.S_TEXTO));
        lim.add(Cell.n(LIMIAR_PADRAO, XlsxWriter.S_MEDIA));
        lim.add(Cell.t("← pode alterar", XlsxWriter.S_NORMAL));
        cr.row();
        List<Cell> lh = cr.row();
        lh.add(Cell.t("Nota", XlsxWriter.S_CAB));
        lh.add(Cell.t("Descritor", XlsxWriter.S_CAB));
        for (int v = 1; v <= 5; v++) {
            List<Cell> row = cr.row();
            row.add(Cell.n(v, XlsxWriter.S_N1 + v - 1));
            row.add(Cell.t(Store.DESCRITORES[v], XlsxWriter.S_TEXTO));
        }
        cr.row();
        List<Cell> nh = cr.row();
        nh.add(Cell.t("Nível de Atividades Físicas (70%)", XlsxWriter.S_CAB));
        nh.add(Cell.t("Matérias atingidas 1.º S", XlsxWriter.S_CAB));
        nh.add(Cell.t("2.º S", XlsxWriter.S_CAB));
        int[][] tab = {{1, 1, 1}, {2, 3, 4}, {3, 4, 6}, {4, 5, 7}, {5, 7, 9}};
        for (int[] l : tab) {
            List<Cell> row = cr.row();
            row.add(Cell.n(l[0], XlsxWriter.S_CENTRO));
            row.add(Cell.n(l[1], XlsxWriter.S_CENTRO));
            row.add(Cell.n(l[2], XlsxWriter.S_CENTRO));
        }
        cr.row();
        cr.row().add(Cell.t("Os níveis de introdução têm de incluir pelo menos 1 Jogo Desportivo Coletivo (JDC) e 1 Ginástica (GIN).", XlsxWriter.S_NORMAL));
        cr.row().add(Cell.t("A classificação final soma ainda a Aptidão Física (20%) e os Conhecimentos (10%).", XlsxWriter.S_NORMAL));

        x.write(out);
    }

    static int nivel1(int a) { return a >= 7 ? 5 : a >= 5 ? 4 : a >= 4 ? 3 : a >= 3 ? 2 : 1; }

    static int nivel2(int a) { return a >= 9 ? 5 : a >= 7 ? 4 : a >= 6 ? 3 : a >= 4 ? 2 : 1; }

    /** Matérias com notas nesta turma (pela ordem da lista), incluindo elementos já removidos da lista. */
    static List<Store.Materia> materiasDaTurma(Store st, Store.Turma t) {
        List<Store.Materia> l = new ArrayList<>();
        List<String> nomes = new ArrayList<>();
        for (Store.Materia m : st.materias) nomes.add(m.nome);
        for (Store.Nota n : st.notas) if (n.turmaId.equals(t.id) && !nomes.contains(n.materia)) nomes.add(n.materia);
        for (String nome : nomes) {
            Store.Materia orig = st.materia(nome);
            Store.Materia m = new Store.Materia();
            m.nome = nome;
            m.area = orig == null ? "" : orig.area;
            List<String> usados = new ArrayList<>();
            for (Store.Nota n : st.notas)
                if (n.turmaId.equals(t.id) && n.materia.equals(nome) && !usados.contains(n.elemento)) usados.add(n.elemento);
            if (usados.isEmpty()) continue;
            if (orig != null) for (String e : orig.elementos) if (usados.contains(e)) m.elementos.add(e);
            for (String e : usados) if (!m.elementos.contains(e)) m.elementos.add(e);
            l.add(m);
        }
        return l;
    }
}
