package pt.notafalada;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;

/** Guarda os dados num ficheiro JSON dentro da aplicação. */
public class Storage {

    private static final String FICHEIRO = "dados.json";

    public static Store load(Context ctx) {
        File f = new File(ctx.getFilesDir(), FICHEIRO);
        Store st = new Store();
        if (!f.exists()) {
            st.materias = Store.materiasPadrao();
            return st;
        }
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONObject o = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));

            JSONArray ts = o.optJSONArray("turmas");
            if (ts != null) for (int i = 0; i < ts.length(); i++) {
                JSONObject j = ts.getJSONObject(i);
                Store.Turma t = new Store.Turma();
                t.id = j.getString("id");
                t.ano = j.optString("ano", "");
                t.nome = j.optString("nome", "");
                JSONArray al = j.optJSONArray("alunos");
                if (al != null) for (int k = 0; k < al.length(); k++) t.alunos.add(al.getString(k));
                st.turmas.add(t);
            }
            JSONArray ms = o.optJSONArray("materias");
            if (ms != null) for (int i = 0; i < ms.length(); i++) {
                JSONObject j = ms.getJSONObject(i);
                Store.Materia m = new Store.Materia();
                m.nome = j.getString("nome");
                m.area = j.optString("area", "");
                JSONArray el = j.optJSONArray("elementos");
                if (el != null) for (int k = 0; k < el.length(); k++) m.elementos.add(el.getString(k));
                st.materias.add(m);
            }
            else st.materias = Store.materiasPadrao();
            JSONArray ns = o.optJSONArray("notas");
            if (ns != null) for (int i = 0; i < ns.length(); i++) {
                JSONObject j = ns.getJSONObject(i);
                Store.Nota n2 = new Store.Nota();
                n2.turmaId = j.getString("t");
                n2.aluno = j.getString("a");
                n2.materia = j.getString("m");
                n2.elemento = j.getString("e");
                n2.valor = j.getInt("v");
                n2.data = j.optLong("d", System.currentTimeMillis());
                st.notas.add(n2);
            }
        } catch (Exception e) {
            // ficheiro estragado: guarda uma cópia e começa de novo
            //noinspection ResultOfMethodCallIgnored
            f.renameTo(new File(ctx.getFilesDir(), "dados-estragado-" + System.currentTimeMillis() + ".json"));
            st = new Store();
            st.materias = Store.materiasPadrao();
        }
        return st;
    }

    public static void save(Context ctx, Store st) {
        try {
            JSONObject o = new JSONObject();
            JSONArray ts = new JSONArray();
            for (Store.Turma t : st.turmas) {
                JSONObject j = new JSONObject();
                j.put("id", t.id);
                j.put("ano", t.ano);
                j.put("nome", t.nome);
                JSONArray al = new JSONArray();
                for (String a : t.alunos) al.put(a);
                j.put("alunos", al);
                ts.put(j);
            }
            o.put("turmas", ts);
            JSONArray ms = new JSONArray();
            for (Store.Materia m : st.materias) {
                JSONObject j = new JSONObject();
                j.put("nome", m.nome);
                j.put("area", m.area);
                JSONArray el = new JSONArray();
                for (String e : m.elementos) el.put(e);
                j.put("elementos", el);
                ms.put(j);
            }
            o.put("materias", ms);
            JSONArray ns = new JSONArray();
            for (Store.Nota n : st.notas) {
                JSONObject j = new JSONObject();
                j.put("t", n.turmaId);
                j.put("a", n.aluno);
                j.put("m", n.materia);
                j.put("e", n.elemento);
                j.put("v", n.valor);
                j.put("d", n.data);
                ns.put(j);
            }
            o.put("notas", ns);

            File tmp = new File(ctx.getFilesDir(), FICHEIRO + ".tmp");
            try (OutputStream out = new FileOutputStream(tmp)) {
                out.write(o.toString().getBytes(StandardCharsets.UTF_8));
            }
            File f = new File(ctx.getFilesDir(), FICHEIRO);
            if (!tmp.renameTo(f)) {
                try (OutputStream out = new FileOutputStream(f)) {
                    out.write(o.toString().getBytes(StandardCharsets.UTF_8));
                }
            }
        } catch (Exception ignored) {
        }
    }
}
