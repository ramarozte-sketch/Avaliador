package pt.notafalada;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Escritor mínimo de ficheiros .xlsx (Excel), sem bibliotecas externas. */
public class XlsxWriter {

    // Estilos (índices em cellXfs, ver styles())
    public static final int S_NORMAL = 0, S_CAB = 1, S_TEXTO = 2,
            S_N1 = 3, S_N2 = 4, S_N3 = 5, S_N4 = 6, S_N5 = 7,
            S_MEDIA = 8, S_TITULO = 9, S_CENTRO = 10;

    public static class Cell {
        String text; Double num; String formula; int style;
        public String cachedText;
        public static Cell t(String s, int style) { Cell c = new Cell(); c.text = s; c.style = style; return c; }
        public static Cell n(double v, int style) { Cell c = new Cell(); c.num = v; c.style = style; return c; }
        public static Cell f(String formula, Double cached, int style) {
            Cell c = new Cell(); c.formula = formula; c.num = cached; c.style = style; return c;
        }
        public static Cell empty(int style) { Cell c = new Cell(); c.style = style; return c; }
    }

    public static class Sheet {
        public String name;
        public List<List<Cell>> rows = new ArrayList<>();
        public List<Double> widths = new ArrayList<>();
        public int freezeRows, freezeCols;
        public List<String> merges = new ArrayList<>();
        public List<Cell> row() { List<Cell> r = new ArrayList<>(); rows.add(r); return r; }
    }

    private final List<Sheet> sheets = new ArrayList<>();
    private final Set<String> names = new HashSet<>();

    public Sheet addSheet(String wanted) {
        String n = wanted.replaceAll("[\\[\\]:*?/\\\\]", "-").trim();
        if (n.isEmpty()) n = "Folha";
        if (n.length() > 31) n = n.substring(0, 31);
        String base = n; int k = 2;
        while (names.contains(n.toLowerCase())) {
            String suf = " (" + k++ + ")";
            n = (base.length() + suf.length() > 31 ? base.substring(0, 31 - suf.length()) : base) + suf;
        }
        names.add(n.toLowerCase());
        Sheet s = new Sheet(); s.name = n; sheets.add(s);
        return s;
    }

    public static String col(int idx) { // 0 -> A
        StringBuilder b = new StringBuilder();
        idx++;
        while (idx > 0) { int m = (idx - 1) % 26; b.insert(0, (char) ('A' + m)); idx = (idx - 1) / 26; }
        return b.toString();
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '&': b.append("&amp;"); break;
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                default:
                    if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') continue;
                    b.append(c);
            }
        }
        return b.toString();
    }

    public void write(OutputStream out) throws IOException {
        if (sheets.isEmpty()) addSheet("Folha1");
        ZipOutputStream z = new ZipOutputStream(out);
        put(z, "[Content_Types].xml", contentTypes());
        put(z, "_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                        + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                        + "</Relationships>");
        put(z, "xl/workbook.xml", workbook());
        put(z, "xl/_rels/workbook.xml.rels", workbookRels());
        put(z, "xl/styles.xml", styles());
        for (int i = 0; i < sheets.size(); i++) put(z, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(sheets.get(i)));
        z.finish();
        z.flush();
    }

    private static void put(ZipOutputStream z, String name, String content) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    private String contentTypes() {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                .append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
                .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
                .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
                .append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
                .append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for (int i = 0; i < sheets.size(); i++)
            b.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
                    .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        b.append("</Types>");
        return b.toString();
    }

    private String workbook() {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                .append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" ")
                .append("xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">")
                .append("<sheets>");
        for (int i = 0; i < sheets.size(); i++)
            b.append("<sheet name=\"").append(esc(sheets.get(i).name)).append("\" sheetId=\"").append(i + 1)
                    .append("\" r:id=\"rId").append(i + 1).append("\"/>");
        b.append("</sheets><calcPr fullCalcOnLoad=\"1\"/></workbook>");
        return b.toString();
    }

    private String workbookRels() {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                .append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 0; i < sheets.size(); i++)
            b.append("<Relationship Id=\"rId").append(i + 1)
                    .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                    .append(i + 1).append(".xml\"/>");
        int s = sheets.size() + 1;
        b.append("<Relationship Id=\"rId").append(s)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
        b.append("</Relationships>");
        return b.toString();
    }

    private static String fill(String rgb) {
        return "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF" + rgb + "\"/><bgColor indexed=\"64\"/></patternFill></fill>";
    }

    private String styles() {
        String center = "<alignment horizontal=\"center\" vertical=\"center\"/>";
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"0.0\"/></numFmts>"
                + "<fonts count=\"4\">"
                + "<font><sz val=\"11\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"14\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"11\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
                + "</fonts>"
                + "<fills count=\"8\">"
                + "<fill><patternFill patternType=\"none\"/></fill>"
                + "<fill><patternFill patternType=\"gray125\"/></fill>"
                + fill("1F5F5B")   // 2 cabeçalho
                + fill("F4B6B0")   // 3 nota 1
                + fill("F9D3A5")   // 4 nota 2
                + fill("FBEBA0")   // 5 nota 3
                + fill("CFE8B5")   // 6 nota 4
                + fill("98D39A")   // 7 nota 5
                + "</fills>"
                + "<borders count=\"2\">"
                + "<border><left/><right/><top/><bottom/><diagonal/></border>"
                + "<border><left style=\"thin\"><color rgb=\"FFB7C4C2\"/></left><right style=\"thin\"><color rgb=\"FFB7C4C2\"/></right>"
                + "<top style=\"thin\"><color rgb=\"FFB7C4C2\"/></top><bottom style=\"thin\"><color rgb=\"FFB7C4C2\"/></bottom><diagonal/></border>"
                + "</borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"11\">"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" + center + "</xf>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"4\" borderId=\"1\" xfId=\"0\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" + center + "</xf>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"5\" borderId=\"1\" xfId=\"0\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" + center + "</xf>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"6\" borderId=\"1\" xfId=\"0\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" + center + "</xf>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"7\" borderId=\"1\" xfId=\"0\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" + center + "</xf>"
                + "<xf numFmtId=\"164\" fontId=\"3\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" + center + "</xf>"
                + "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\" applyAlignment=\"1\">" + center + "</xf>"
                + "</cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>";
    }

    private String sheetXml(Sheet s) {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                .append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        b.append("<sheetViews><sheetView workbookViewId=\"0\"");
        if (s.freezeRows > 0 || s.freezeCols > 0) {
            String cell = col(s.freezeCols) + (s.freezeRows + 1);
            b.append("><pane");
            if (s.freezeCols > 0) b.append(" xSplit=\"").append(s.freezeCols).append("\"");
            if (s.freezeRows > 0) b.append(" ySplit=\"").append(s.freezeRows).append("\"");
            String pane = s.freezeRows > 0 && s.freezeCols > 0 ? "bottomRight" : (s.freezeRows > 0 ? "bottomLeft" : "topRight");
            b.append(" topLeftCell=\"").append(cell).append("\" activePane=\"").append(pane)
                    .append("\" state=\"frozen\"/></sheetView>");
        } else {
            b.append("/>");
        }
        b.append("</sheetViews>");
        if (!s.widths.isEmpty()) {
            b.append("<cols>");
            for (int i = 0; i < s.widths.size(); i++)
                b.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1)
                        .append("\" width=\"").append(s.widths.get(i)).append("\" customWidth=\"1\"/>");
            b.append("</cols>");
        }
        b.append("<sheetData>");
        for (int r = 0; r < s.rows.size(); r++) {
            List<Cell> row = s.rows.get(r);
            b.append("<row r=\"").append(r + 1).append("\">");
            for (int c = 0; c < row.size(); c++) {
                Cell cell = row.get(c);
                if (cell == null) continue;
                String ref = col(c) + (r + 1);
                b.append("<c r=\"").append(ref).append("\"");
                if (cell.style != 0) b.append(" s=\"").append(cell.style).append("\"");
                if (cell.formula != null) {
                    if (cell.cachedText != null) b.append(" t=\"str\"");
                    b.append("><f>").append(esc(cell.formula)).append("</f>");
                    if (cell.cachedText != null) b.append("<v>").append(esc(cell.cachedText)).append("</v>");
                    else if (cell.num != null) b.append("<v>").append(fmt(cell.num)).append("</v>");
                    b.append("</c>");
                } else if (cell.num != null) {
                    b.append("><v>").append(fmt(cell.num)).append("</v></c>");
                } else if (cell.text != null) {
                    b.append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(cell.text)).append("</t></is></c>");
                } else {
                    b.append("/>");
                }
            }
            b.append("</row>");
        }
        b.append("</sheetData>");
        if (!s.merges.isEmpty()) {
            b.append("<mergeCells count=\"").append(s.merges.size()).append("\">");
            for (String m : s.merges) b.append("<mergeCell ref=\"").append(m).append("\"/>");
            b.append("</mergeCells>");
        }
        b.append("<pageMargins left=\"0.5\" right=\"0.5\" top=\"0.6\" bottom=\"0.6\" header=\"0.3\" footer=\"0.3\"/>");
        b.append("</worksheet>");
        return b.toString();
    }

    private static String fmt(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return Long.toString((long) v);
        return Double.toString(v);
    }
}
