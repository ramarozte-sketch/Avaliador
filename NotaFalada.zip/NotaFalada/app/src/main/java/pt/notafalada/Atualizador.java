package pt.notafalada;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Atualizações diretas: procura a última "Release" do repositório no GitHub,
 * descarrega o APK e instala-o por cima da versão atual (as notas mantêm-se).
 */
public class Atualizador {

    public static final String ACAO_INSTALACAO = "pt.notafalada.INSTALACAO";

    public interface Verificacao {
        void novaVersao(int versao, String url, String notas);

        void semNovidades();

        void erro(String mensagem);
    }

    public interface Progresso {
        void progresso(int percentagem);

        void erro(String mensagem);
    }

    public static int versaoAtual() {
        return BuildConfig.VERSION_CODE;
    }

    public static void verificar(final Activity a, final Verificacao v) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(
                        "https://api.github.com/repos/" + BuildConfig.REPO + "/releases/latest").openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                int code = c.getResponseCode();
                if (code == 404) {
                    a.runOnUiThread(() -> v.erro("Ainda não há versões publicadas, ou o repositório "
                            + BuildConfig.REPO + " é privado (tem de ser público)."));
                    return;
                }
                if (code != 200) {
                    a.runOnUiThread(() -> v.erro("O GitHub respondeu com o código " + code + "."));
                    return;
                }
                JSONObject o = new JSONObject(ler(c.getInputStream()));
                int versao = numero(o.optString("tag_name", ""));
                String url = null;
                JSONArray assets = o.optJSONArray("assets");
                if (assets != null) for (int i = 0; i < assets.length(); i++) {
                    JSONObject as = assets.getJSONObject(i);
                    if (as.optString("name", "").toLowerCase().endsWith(".apk")) {
                        url = as.optString("browser_download_url", null);
                        break;
                    }
                }
                final String fUrl = url;
                final String notas = o.optString("name", "");
                if (versao > versaoAtual() && fUrl != null) a.runOnUiThread(() -> v.novaVersao(versao, fUrl, notas));
                else a.runOnUiThread(v::semNovidades);
            } catch (Exception e) {
                a.runOnUiThread(() -> v.erro("Sem ligação ao GitHub (" + e.getMessage() + ")."));
            }
        }).start();
    }

    /** Descarrega o APK e entrega-o ao instalador do Android. O resultado chega à atividade por onNewIntent. */
    public static void instalar(final Activity a, final String url, final Progresso p) {
        new Thread(() -> {
            File f = new File(a.getCacheDir(), "atualizacao.apk");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                // o GitHub redireciona para outro servidor: segue até 5 redirecionamentos
                for (int i = 0; i < 5; i++) {
                    int code = c.getResponseCode();
                    if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                        String loc = c.getHeaderField("Location");
                        c.disconnect();
                        c = (HttpURLConnection) new URL(loc).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(30000);
                    } else break;
                }
                if (c.getResponseCode() != 200) throw new Exception("código " + c.getResponseCode());
                long total = c.getContentLengthLong();
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(f)) {
                    byte[] buf = new byte[65536];
                    long lidos = 0;
                    int n, ultimo = -1;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        lidos += n;
                        if (total > 0) {
                            int pct = (int) (lidos * 100 / total);
                            if (pct != ultimo) {
                                ultimo = pct;
                                a.runOnUiThread(() -> p.progresso(pct));
                            }
                        }
                    }
                }

                PackageInstaller pi = a.getPackageManager().getPackageInstaller();
                PackageInstaller.SessionParams params =
                        new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                int id = pi.createSession(params);
                PackageInstaller.Session s = pi.openSession(id);
                try (OutputStream out = s.openWrite("notafalada", 0, f.length());
                     InputStream in = new FileInputStream(f)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    s.fsync(out);
                }
                Intent i = new Intent(a, MainActivity.class);
                i.setAction(ACAO_INSTALACAO);
                i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
                PendingIntent pend = PendingIntent.getActivity(a, 7, i, flags);
                s.commit(pend.getIntentSender());
                s.close();
            } catch (Exception e) {
                a.runOnUiThread(() -> p.erro("Não foi possível descarregar ou instalar: " + e.getMessage()));
            }
        }).start();
    }

    private static String ler(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return new String(b.toByteArray(), StandardCharsets.UTF_8);
    }

    /** "v12" -> 12 */
    static int numero(String tag) {
        StringBuilder d = new StringBuilder();
        for (char ch : tag.toCharArray()) if (Character.isDigit(ch)) d.append(ch);
        if (d.length() == 0) return 0;
        try {
            return Integer.parseInt(d.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
