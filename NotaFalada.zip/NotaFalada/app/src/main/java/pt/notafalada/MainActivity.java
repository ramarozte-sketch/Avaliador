package pt.notafalada;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.PackageInstaller;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity implements RecognitionListener {

    // ---------- cores ----------
    private static final int C_FUNDO = 0xFFF2F5F4;
    private static final int C_CARTAO = 0xFFFFFFFF;
    private static final int C_TEXTO = 0xFF17302E;
    private static final int C_SUAVE = 0xFF5D706E;
    private static final int C_PRINCIPAL = 0xFF1F5F5B;
    private static final int C_OUVIR = 0xFFC2412D;
    private static final int C_LINHA = 0xFFDCE4E2;
    private static final int C_FOCO = 0xFFE3F0EE;
    private static final int C_OK = 0xFF2E7D4F;
    private static final int C_ERRO = 0xFFB3261E;
    private static final int[] C_NOTA = {0, 0xFFE57368, 0xFFF0A65A, 0xFFE0BC2E, 0xFF8CC765, 0xFF3FA65A};

    private static final int REQ_MIC = 1;
    private static final int REQ_EXPORTAR = 2;
    private static final String XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private static final Locale PT = new Locale("pt", "PT");

    private Store store;
    private String turmaId, materia, elemento, foco;
    private boolean vistaPorAluno;
    private SharedPreferences prefs;

    private SpeechRecognizer recognizer;
    private boolean aOuvir;
    private boolean somDesligado;
    private boolean silenciado;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private Spinner spTurma, spMateria, spElemento;
    private Button btOuvir, btPorElemento, btPorAluno;
    private TextView tvEstado, tvOuvido, tvFoco, tvProgresso;
    private LinearLayout boxRegisto, boxNotas;
    private EditText etManual;

    private static class Undo {
        String turmaId, aluno, materia, elemento;
        Store.Nota anterior;
    }

    private final Deque<Undo> desfazer = new ArrayDeque<>();

    private static class Linha {
        String texto;
        int cor;
        Runnable toque;
    }

    private final List<Linha> registo = new ArrayList<>();

    // =====================================================================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        store = Storage.load(this);
        turmaId = prefs.getString("turma", null);
        materia = prefs.getString("materia", null);
        elemento = prefs.getString("elemento", null);
        somDesligado = prefs.getBoolean("semSom", true);
        validarSelecao();

        construirEcra();
        atualizarSpinners();
        atualizarFoco();
        atualizarNotas();

        if (store.turmas.isEmpty()) handler.postDelayed(() -> dialogoTurma(null), 400);

        // procura atualizações em silêncio, no máximo de 6 em 6 horas
        long agora = System.currentTimeMillis();
        if (agora - prefs.getLong("ultimaVerificacao", 0) > 6 * 3600 * 1000L) {
            prefs.edit().putLong("ultimaVerificacao", agora).apply();
            procurarAtualizacao(false);
        }
    }

    // =====================================================================
    // Atualizações diretas

    private AlertDialog dlgDownload;

    private void procurarAtualizacao(final boolean avisar) {
        if (avisar) toast("A procurar atualizações…");
        Atualizador.verificar(this, new Atualizador.Verificacao() {
            @Override
            public void novaVersao(int versao, String url, String notas) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Nova versão disponível")
                        .setMessage("Tem a versão " + Atualizador.versaoAtual() + " e já existe a versão " + versao
                                + ". As turmas e as notas mantêm-se. Atualizar agora?")
                        .setPositiveButton("Atualizar", (d, w) -> instalarAtualizacao(url))
                        .setNegativeButton("Mais tarde", null)
                        .show();
            }

            @Override
            public void semNovidades() {
                if (avisar) toast("Já tem a versão mais recente (" + Atualizador.versaoAtual() + ").");
            }

            @Override
            public void erro(String mensagem) {
                if (avisar) toast(mensagem);
            }
        });
    }

    private void instalarAtualizacao(final String url) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this)
                    .setTitle("Autorizar atualizações")
                    .setMessage("Para a app se atualizar sozinha, o Android precisa da sua autorização "
                            + "(«Instalar apps desconhecidas»). Ative a opção no ecrã seguinte, volte e toque "
                            + "outra vez em «Atualizar».")
                    .setPositiveButton("Abrir definições", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (ActivityNotFoundException e) {
                            toast("Abra as definições do Android e permita que a Nota Falada instale apps.");
                        }
                        prefs.edit().putLong("ultimaVerificacao", 0).apply();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        if (aOuvir) pararOuvir();
        final TextView msg = texto("A descarregar… 0%", 16, C_TEXTO, false);
        msg.setPadding(dp(24), dp(16), dp(24), dp(8));
        dlgDownload = new AlertDialog.Builder(this)
                .setTitle("Atualizar")
                .setView(msg)
                .setCancelable(false)
                .show();
        Atualizador.instalar(this, url, new Atualizador.Progresso() {
            @Override
            public void progresso(int pct) {
                msg.setText(pct >= 100 ? "A instalar…" : "A descarregar… " + pct + "%");
            }

            @Override
            public void erro(String mensagem) {
                fecharDownload();
                toast(mensagem);
            }
        });
    }

    private void fecharDownload() {
        if (dlgDownload != null) {
            try {
                dlgDownload.dismiss();
            } catch (Exception ignored) {
            }
            dlgDownload = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent == null || !Atualizador.ACAO_INSTALACAO.equals(intent.getAction())) return;
        int estado = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        if (estado == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirmar = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirmar != null) {
                try {
                    startActivity(confirmar);
                } catch (Exception e) {
                    toast("Não foi possível abrir o instalador.");
                }
            }
            return;
        }
        fecharDownload();
        if (estado == PackageInstaller.STATUS_SUCCESS) {
            toast("Atualizado.");
        } else if (estado != PackageInstaller.STATUS_FAILURE_ABORTED) {
            String m = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
            new AlertDialog.Builder(this)
                    .setTitle("A atualização falhou")
                    .setMessage((m == null ? "" : m + "\n\n")
                            + "Se o erro falar de assinatura ou conflito, a versão instalada foi compilada antes das "
                            + "atualizações diretas. Exporte o Excel, desinstale a app e instale o APK novo uma vez; "
                            + "a partir daí as atualizações passam a ser diretas.")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    /** Garante que turma, matéria e elemento escolhidos existem. */
    private void validarSelecao() {
        if (store.turma(turmaId) == null) turmaId = store.turmas.isEmpty() ? null : store.turmasOrdenadas().get(0).id;
        Store.Materia m = store.materia(materia);
        if (m == null) {
            m = store.materias.isEmpty() ? null : store.materias.get(0);
            materia = m == null ? null : m.nome;
        }
        if (m == null || !m.elementos.contains(elemento)) elemento = null;
        Store.Turma t = store.turma(turmaId);
        if (foco != null && (t == null || !t.alunos.contains(foco))) foco = null;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (aOuvir) pararOuvir();
        guardarPrefs();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        silenciar(false);
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
    }

    // =====================================================================
    // Construção do ecrã

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable fundo(int cor, float raio, int borda) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(cor);
        g.setCornerRadius(dp(raio));
        if (borda != 0) g.setStroke(dp(1), borda);
        return g;
    }

    private TextView texto(String s, float sp, int cor, boolean negrito) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(cor);
        if (negrito) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button botao(String s, int fundoCor, int textoCor) {
        Button bt = new Button(this);
        bt.setText(s);
        bt.setAllCaps(false);
        bt.setTextColor(textoCor);
        bt.setTextSize(15);
        bt.setBackground(fundo(fundoCor, 10, fundoCor == C_CARTAO ? C_LINHA : 0));
        bt.setPadding(dp(14), dp(8), dp(14), dp(8));
        bt.setMinHeight(dp(44));
        bt.setMinimumHeight(dp(44));
        return bt;
    }

    private LinearLayout cartao(LinearLayout pai) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(fundo(C_CARTAO, 14, C_LINHA));
        c.setPadding(dp(14), dp(12), dp(14), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        pai.addView(c, lp);
        return c;
    }

    private TextView rotulo(String s) {
        TextView t = texto(s, 12, C_SUAVE, true);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private LinearLayout linhaSpinner(Spinner sp, Button bt) {
        LinearLayout l = new LinearLayout(this);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.addView(sp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (bt != null) l.addView(bt);
        return l;
    }

    private void construirEcra() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_FUNDO);
        sv.setFillViewport(true);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setPadding(dp(16), dp(4), dp(16), dp(24));
        sv.addView(raiz);

        // ----- Turma, matéria, elemento -----
        LinearLayout c1 = cartao(raiz);
        TextView lt = texto("TURMA", 12, C_SUAVE, true);
        c1.addView(lt);
        spTurma = new Spinner(this);
        Button btTurmas = botao("Turmas", C_CARTAO, C_PRINCIPAL);
        btTurmas.setOnClickListener(v -> dialogoListaTurmas());
        c1.addView(linhaSpinner(spTurma, btTurmas));

        c1.addView(rotulo("MATÉRIA"));
        spMateria = new Spinner(this);
        Button btMat = botao("Editar", C_CARTAO, C_PRINCIPAL);
        btMat.setOnClickListener(v -> dialogoMaterias());
        c1.addView(linhaSpinner(spMateria, btMat));

        c1.addView(rotulo("ELEMENTO A AVALIAR"));
        spElemento = new Spinner(this);
        c1.addView(linhaSpinner(spElemento, null));

        spTurma.setOnItemSelectedListener(new SelecaoSimples() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                List<Store.Turma> ts = store.turmasOrdenadas();
                if (pos >= 0 && pos < ts.size() && !ts.get(pos).id.equals(turmaId)) {
                    turmaId = ts.get(pos).id;
                    foco = null;
                    guardarPrefs();
                    atualizarFoco();
                    atualizarNotas();
                }
            }
        });
        spMateria.setOnItemSelectedListener(new SelecaoSimples() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < store.materias.size() && !store.materias.get(pos).nome.equals(materia)) {
                    mudarMateria(store.materias.get(pos).nome, null);
                }
            }
        });
        spElemento.setOnItemSelectedListener(new SelecaoSimples() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                Store.Materia m = store.materia(materia);
                String novo = m == null || pos < 1 || pos > m.elementos.size() ? null : m.elementos.get(pos - 1);
                if (novo == null ? elemento != null : !novo.equals(elemento)) {
                    elemento = novo;
                    guardarPrefs();
                    atualizarNotas();
                }
            }
        });

        // ----- Voz -----
        LinearLayout c2 = cartao(raiz);
        btOuvir = botao("Começar a ouvir", C_PRINCIPAL, Color.WHITE);
        btOuvir.setTextSize(20);
        btOuvir.setTypeface(Typeface.DEFAULT_BOLD);
        btOuvir.setOnClickListener(v -> {
            if (aOuvir) pararOuvir();
            else comecarOuvir();
        });
        c2.addView(btOuvir, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)));
        tvEstado = texto("", 14, C_SUAVE, false);
        tvEstado.setPadding(0, dp(10), 0, 0);
        c2.addView(tvEstado);
        estadoParado();
        tvOuvido = texto("", 18, C_TEXTO, true);
        tvOuvido.setPadding(0, dp(6), 0, 0);
        c2.addView(tvOuvido);

        LinearLayout lf = new LinearLayout(this);
        lf.setGravity(Gravity.CENTER_VERTICAL);
        lf.setPadding(dp(10), dp(4), dp(4), dp(4));
        lf.setBackground(fundo(C_FOCO, 10, 0));
        tvFoco = texto("", 14, C_PRINCIPAL, true);
        lf.addView(tvFoco, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button btLimpar = botao("Largar", C_FOCO, C_PRINCIPAL);
        btLimpar.setOnClickListener(v -> {
            foco = null;
            atualizarFoco();
            atualizarNotas();
        });
        lf.addView(btLimpar);
        LinearLayout.LayoutParams lpf = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpf.topMargin = dp(10);
        c2.addView(lf, lpf);

        LinearLayout lm = new LinearLayout(this);
        lm.setGravity(Gravity.CENTER_VERTICAL);
        lm.setPadding(0, dp(10), 0, 0);
        etManual = new EditText(this);
        etManual.setHint("Ou escreva: Jesus 4 Gabriel 2");
        etManual.setSingleLine(true);
        etManual.setImeOptions(EditorInfo.IME_ACTION_DONE);
        etManual.setOnEditorActionListener((v, a, e) -> {
            registarManual();
            return true;
        });
        lm.addView(etManual, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button btReg = botao("Registar", C_CARTAO, C_PRINCIPAL);
        btReg.setOnClickListener(v -> registarManual());
        lm.addView(btReg);
        c2.addView(lm);

        // ----- Últimos registos -----
        LinearLayout c3 = cartao(raiz);
        LinearLayout h3 = new LinearLayout(this);
        h3.setGravity(Gravity.CENTER_VERTICAL);
        h3.addView(texto("ÚLTIMOS REGISTOS", 12, C_SUAVE, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button btAnular = botao("Anular último", C_CARTAO, C_ERRO);
        btAnular.setOnClickListener(v -> anular());
        h3.addView(btAnular);
        c3.addView(h3);
        boxRegisto = new LinearLayout(this);
        boxRegisto.setOrientation(LinearLayout.VERTICAL);
        c3.addView(boxRegisto);
        mostrarRegisto();

        // ----- Notas -----
        LinearLayout c4 = cartao(raiz);
        LinearLayout abas = new LinearLayout(this);
        btPorElemento = botao("Por elemento", C_PRINCIPAL, Color.WHITE);
        btPorAluno = botao("Por aluno", C_CARTAO, C_PRINCIPAL);
        btPorElemento.setOnClickListener(v -> { vistaPorAluno = false; atualizarNotas(); });
        btPorAluno.setOnClickListener(v -> { vistaPorAluno = true; atualizarNotas(); });
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        abas.addView(btPorElemento, la);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        lb.leftMargin = dp(8);
        abas.addView(btPorAluno, lb);
        c4.addView(abas);
        tvProgresso = texto("", 12, C_SUAVE, true);
        tvProgresso.setPadding(0, dp(10), 0, dp(2));
        c4.addView(tvProgresso);
        boxNotas = new LinearLayout(this);
        boxNotas.setOrientation(LinearLayout.VERTICAL);
        c4.addView(boxNotas);

        // ----- Exportar -----
        Button btExcel = botao("Exportar Excel", C_PRINCIPAL, Color.WHITE);
        btExcel.setTypeface(Typeface.DEFAULT_BOLD);
        btExcel.setOnClickListener(v -> exportar());
        LinearLayout.LayoutParams lpx = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        lpx.topMargin = dp(14);
        raiz.addView(btExcel, lpx);

        setContentView(sv);
    }

    private abstract static class SelecaoSimples implements AdapterView.OnItemSelectedListener {
        @Override
        public void onNothingSelected(AdapterView<?> p) {
        }
    }

    // =====================================================================
    // Atualizações do ecrã

    private void atualizarSpinners() {
        List<String> nt = new ArrayList<>();
        int selT = 0;
        List<Store.Turma> ts = store.turmasOrdenadas();
        for (int i = 0; i < ts.size(); i++) {
            Store.Turma t = ts.get(i);
            nt.add(t.label() + "  (" + t.alunos.size() + " alunos)");
            if (t.id.equals(turmaId)) selT = i;
        }
        if (nt.isEmpty()) nt.add("— crie uma turma —");
        spTurma.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, nt));
        spTurma.setSelection(selT);

        List<String> nm = new ArrayList<>();
        int selM = 0;
        for (int i = 0; i < store.materias.size(); i++) {
            Store.Materia m = store.materias.get(i);
            nm.add(m.nome + (m.area.isEmpty() ? "" : "  · " + m.area));
            if (m.nome.equals(materia)) selM = i;
        }
        if (nm.isEmpty()) nm.add("— adicione matérias —");
        spMateria.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, nm));
        spMateria.setSelection(selM);
        atualizarSpinnerElementos();
    }

    private void atualizarSpinnerElementos() {
        Store.Materia m = store.materia(materia);
        List<String> ne = new ArrayList<>();
        ne.add("— diga ou escolha o elemento —");
        if (m != null) ne.addAll(m.elementos);
        spElemento.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, ne));
        int sel = m == null || elemento == null ? 0 : m.elementos.indexOf(elemento) + 1;
        spElemento.setSelection(Math.max(0, sel));
    }

    /** Muda de matéria; sem elemento dito, fica à espera que seja dito ou escolhido. */
    private void mudarMateria(String nova, String novoElemento) {
        materia = nova;
        Store.Materia m = store.materia(nova);
        elemento = novoElemento;
        if (elemento == null && m != null && m.elementos.size() == 1) elemento = m.elementos.get(0);
        guardarPrefs();
        int pos = store.materias.indexOf(m);
        if (pos >= 0 && spMateria.getSelectedItemPosition() != pos) spMateria.setSelection(pos);
        atualizarSpinnerElementos();
        atualizarNotas();
    }

    private void mudarElemento(String novo) {
        elemento = novo;
        guardarPrefs();
        Store.Materia m = store.materia(materia);
        if (m != null) spElemento.setSelection(Math.max(0, m.elementos.indexOf(novo) + 1));
        atualizarNotas();
    }

    private void atualizarFoco() {
        if (foco == null) tvFoco.setText("Sem aluno em foco. Diga «aluno Jesus» para avaliar vários elementos seguidos.");
        else tvFoco.setText("Aluno em foco: " + foco);
    }

    private void atualizarNotas() {
        boxNotas.removeAllViews();
        btPorElemento.setBackground(fundo(vistaPorAluno ? C_CARTAO : C_PRINCIPAL, 10, vistaPorAluno ? C_LINHA : 0));
        btPorElemento.setTextColor(vistaPorAluno ? C_PRINCIPAL : Color.WHITE);
        btPorAluno.setBackground(fundo(vistaPorAluno ? C_PRINCIPAL : C_CARTAO, 10, vistaPorAluno ? 0 : C_LINHA));
        btPorAluno.setTextColor(vistaPorAluno ? Color.WHITE : C_PRINCIPAL);

        Store.Turma t = store.turma(turmaId);
        Store.Materia m = store.materia(materia);
        if (t == null || m == null) {
            tvProgresso.setText("NOTAS");
            boxNotas.addView(texto("Escolha uma turma e uma matéria.", 14, C_SUAVE, false));
            return;
        }
        if (vistaPorAluno) {
            if (t.alunos.isEmpty()) {
                tvProgresso.setText("POR ALUNO · " + m.nome.toUpperCase(PT));
                boxNotas.addView(texto("Esta turma ainda não tem alunos. Toque em «Turmas» para os escrever.",
                        14, C_SUAVE, false));
                return;
            }
            if (foco == null || !t.alunos.contains(foco)) {
                foco = t.alunos.get(0);
                atualizarFoco();
            }
            seletorAluno(t);
            int feitos = 0;
            for (String e : m.elementos) if (store.nota(t.id, foco, m.nome, e) != null) feitos++;
            tvProgresso.setText((foco + " · " + m.nome + " · " + feitos + "/" + m.elementos.size() + " elementos").toUpperCase(PT));
            for (int i = 0; i < m.elementos.size(); i++) {
                String e = m.elementos.get(i);
                adicionarLinhaNota(e, foco, m.nome, e, e.equals(elemento), null);
                if (i < m.elementos.size() - 1) separador();
            }
            return;
        }
        if (elemento == null) {
            tvProgresso.setText("NOTAS");
            boxNotas.addView(texto("Diga o elemento (ex.: «desmarcação Jesus 4») ou escolha-o acima.", 14, C_SUAVE, false));
            return;
        }
        int feitos = 0;
        for (String a : t.alunos) if (store.nota(t.id, a, m.nome, elemento) != null) feitos++;
        tvProgresso.setText((elemento + " · " + feitos + "/" + t.alunos.size() + " avaliados").toUpperCase(PT));
        if (t.alunos.isEmpty()) {
            TextView v = texto("Esta turma ainda não tem alunos. Toque em «Turmas» para os escrever, "
                    + "ou comece a ditar: os nomes ditos são acrescentados à turma.", 14, C_SUAVE, false);
            boxNotas.addView(v);
            return;
        }
        for (int i = 0; i < t.alunos.size(); i++) {
            final String aluno = t.alunos.get(i);
            adicionarLinhaNota((i + 1) + ". " + aluno, aluno, m.nome, elemento, aluno.equals(foco), () -> {
                foco = aluno;
                vistaPorAluno = true;
                atualizarFoco();
                atualizarNotas();
            });
            if (i < t.alunos.size() - 1) separador();
        }
    }

    /** Barra para mudar de aluno na vista «Por aluno»: anterior, lista da turma, seguinte. */
    private void seletorAluno(final Store.Turma t) {
        final int idx = Math.max(0, t.alunos.indexOf(foco));
        LinearLayout barra = new LinearLayout(this);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setPadding(0, 0, 0, dp(8));

        Button ant = botao("◀", C_CARTAO, C_PRINCIPAL);
        ant.setEnabled(idx > 0);
        ant.setAlpha(idx > 0 ? 1f : 0.35f);
        ant.setOnClickListener(v -> escolherFoco(t.alunos.get(idx - 1)));
        barra.addView(ant, new LinearLayout.LayoutParams(dp(52), dp(48)));

        Spinner sp = new Spinner(this);
        List<String> nomes = new ArrayList<>();
        for (int i = 0; i < t.alunos.size(); i++) {
            String a = t.alunos.get(i);
            int n = 0;
            for (Store.Nota x : store.notas) if (x.turmaId.equals(t.id) && x.aluno.equals(a) && x.materia.equals(materia)) n++;
            nomes.add((i + 1) + ". " + a + (n > 0 ? "  ✓" + n : ""));
        }
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, nomes));
        sp.setSelection(idx);
        sp.setOnItemSelectedListener(new SelecaoSimples() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < t.alunos.size() && !t.alunos.get(pos).equals(foco))
                    escolherFoco(t.alunos.get(pos));
            }
        });
        LinearLayout.LayoutParams lsp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        lsp.leftMargin = dp(6);
        lsp.rightMargin = dp(6);
        barra.addView(sp, lsp);

        Button seg = botao("▶", C_CARTAO, C_PRINCIPAL);
        boolean temSeg = idx < t.alunos.size() - 1;
        seg.setEnabled(temSeg);
        seg.setAlpha(temSeg ? 1f : 0.35f);
        seg.setOnClickListener(v -> escolherFoco(t.alunos.get(idx + 1)));
        barra.addView(seg, new LinearLayout.LayoutParams(dp(52), dp(48)));

        boxNotas.addView(barra);
    }

    private void escolherFoco(String aluno) {
        foco = aluno;
        atualizarFoco();
        atualizarNotas();
    }

    private void separador() {
        View sep = new View(this);
        sep.setBackgroundColor(C_LINHA);
        boxNotas.addView(sep, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
    }

    private void adicionarLinhaNota(String rotulo, final String aluno, final String mat, final String elem,
                                    boolean destaque, Runnable toqueNome) {
        Store.Nota n = store.nota(turmaId, aluno, mat, elem);
        LinearLayout linha = new LinearLayout(this);
        linha.setGravity(Gravity.CENTER_VERTICAL);
        linha.setPadding(dp(4), dp(6), 0, dp(6));
        if (destaque) linha.setBackground(fundo(C_FOCO, 8, 0));
        TextView nome = texto(rotulo, 15, C_TEXTO, destaque);
        nome.setPadding(0, dp(6), dp(4), dp(6));
        if (toqueNome != null) nome.setOnClickListener(v -> toqueNome.run());
        linha.addView(nome, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        for (int v = 1; v <= 5; v++) {
            final int valor = v;
            boolean sel = n != null && n.valor == v;
            TextView b = texto(String.valueOf(v), 15, sel ? Color.WHITE : C_SUAVE, sel);
            b.setGravity(Gravity.CENTER);
            b.setBackground(fundo(sel ? C_NOTA[v] : C_CARTAO, 8, sel ? C_NOTA[v] : C_LINHA));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
            lp.leftMargin = dp(4);
            b.setOnClickListener(x -> {
                Store.Nota atual = store.nota(turmaId, aluno, mat, elem);
                if (atual != null && atual.valor == valor) apagarNota(aluno, mat, elem);
                else registar(aluno, mat, elem, valor);
            });
            linha.addView(b, lp);
        }
        boxNotas.addView(linha);
    }

    // =====================================================================
    // Registo de notas

    private void registar(String aluno, String mat, String elem, int valor) {
        if (turmaId == null || mat == null || elem == null) {
            toast("Escolha primeiro a turma, a matéria e o elemento.");
            return;
        }
        Undo u = new Undo();
        u.turmaId = turmaId;
        u.aluno = aluno;
        u.materia = mat;
        u.elemento = elem;
        u.anterior = store.setNota(turmaId, aluno, mat, elem, valor, System.currentTimeMillis());
        desfazer.push(u);
        Storage.save(this, store);
        String extra = u.anterior != null && u.anterior.valor != valor ? "  (era " + u.anterior.valor + ")" : "";
        adicionarLinha(aluno + " · " + elem + " — " + valor + extra, C_OK, null);
        atualizarNotas();
    }

    private void apagarNota(String aluno, String mat, String elem) {
        Store.Nota n = store.nota(turmaId, aluno, mat, elem);
        if (n == null) return;
        Undo u = new Undo();
        u.turmaId = turmaId;
        u.aluno = aluno;
        u.materia = mat;
        u.elemento = elem;
        u.anterior = n.copy();
        store.removeNota(turmaId, aluno, mat, elem);
        desfazer.push(u);
        Storage.save(this, store);
        adicionarLinha(aluno + " · " + elem + " — nota apagada", C_SUAVE, null);
        atualizarNotas();
    }

    private void anular() {
        Undo u = desfazer.poll();
        if (u == null) {
            toast("Não há nada para anular.");
            return;
        }
        if (u.anterior == null) {
            store.removeNota(u.turmaId, u.aluno, u.materia, u.elemento);
            adicionarLinha("Anulado: " + u.aluno + " · " + u.elemento, C_SUAVE, null);
        } else {
            store.setNota(u.turmaId, u.aluno, u.materia, u.elemento, u.anterior.valor, u.anterior.data);
            adicionarLinha("Anulado: " + u.aluno + " · " + u.elemento + " volta a " + u.anterior.valor, C_SUAVE, null);
        }
        Storage.save(this, store);
        atualizarNotas();
    }

    private void registarManual() {
        String s = etManual.getText().toString().trim();
        if (s.isEmpty()) return;
        List<String> l = new ArrayList<>();
        l.add(s);
        tvOuvido.setText("«" + s + "»");
        processar(l);
        etManual.setText("");
    }

    private void processar(List<String> hipoteses) {
        Store.Turma t = store.turma(turmaId);
        if (t == null) {
            toast("Crie primeiro uma turma.");
            return;
        }
        Parser.Result r = Parser.melhor(hipoteses, t.alunos, store.materias, materia, elemento, foco);
        if (r == null || r.vazio()) {
            adicionarLinha("«" + (hipoteses.isEmpty() ? "" : hipoteses.get(0)) + "» — não percebi nenhuma nota", C_SUAVE, null);
            return;
        }
        if (r.anular) {
            anular();
            return;
        }
        // matérias e elementos novos ditos em voz alta
        if (!r.novos.isEmpty()) {
            for (String[] n : r.novos) {
                Store.Materia m = store.materia(n[0]);
                if (m == null) {
                    m = new Store.Materia();
                    m.nome = n[0];
                    store.materias.add(m);
                    adicionarLinha("Nova matéria: " + n[0], C_PRINCIPAL, null);
                }
                if (n[1] != null && !m.elementos.contains(n[1])) {
                    m.elementos.add(n[1]);
                    adicionarLinha("Novo elemento em " + m.nome + ": " + n[1], C_PRINCIPAL, null);
                }
            }
            Storage.save(this, store);
            atualizarSpinners();
        }
        if (r.materia != null && !r.materia.equals(materia)) {
            mudarMateria(r.materia, r.elemento);
            adicionarLinha("Matéria: " + r.materia + (r.elemento != null ? " · " + r.elemento : " — diga o elemento"),
                    C_PRINCIPAL, null);
        } else if (r.elemento != null && !r.elemento.equals(elemento)) {
            mudarElemento(r.elemento);
            adicionarLinha("Elemento: " + r.elemento, C_PRINCIPAL, null);
        }
        String focoAntes = foco;
        foco = r.foco;
        if (r.focoMudou && foco != null) {
            vistaPorAluno = true;
            adicionarLinha("Aluno em foco: " + foco, C_PRINCIPAL, null);
        }

        for (Parser.Item it : r.itens) {
            if (it.nota < 1) {
                final Parser.Item item = it;
                adicionarLinha("«" + it.falado + "» — aluno não reconhecido. Toque para escolher.", C_ERRO,
                        () -> escolherAluno(item, true));
                continue;
            }
            if (it.problema == null) {
                if (it.alunoNovo && !t.alunos.contains(it.aluno)) {
                    t.alunos.add(it.aluno);
                    Storage.save(this, store);
                    atualizarSpinners();
                }
                registar(it.aluno, it.materia != null ? it.materia : materia, it.elemento, it.nota);
            } else {
                final Parser.Item item = it;
                String msg;
                switch (it.problema) {
                    case "ambíguo":
                        msg = "há mais do que um aluno com esse nome";
                        break;
                    case "elemento ambíguo":
                        msg = "qual dos elementos?";
                        break;
                    case "sem aluno":
                        msg = "falta dizer o aluno";
                        break;
                    case "sem elemento":
                        msg = "falta escolher o elemento";
                        break;
                    default:
                        msg = "não reconhecido";
                }
                adicionarLinha("«" + it.falado + "» " + it.nota + " — " + msg + ". Toque para resolver.", C_ERRO,
                        () -> resolverItem(item));
            }
        }
        if (foco == null && focoAntes != null) vistaPorAluno = false;
        atualizarFoco();
        atualizarNotas();
    }

    // ---- resolução de nomes/elementos que não foram percebidos ----

    private void resolverItem(Parser.Item it) {
        if (it.aluno == null) escolherAluno(it, false);
        else if (it.elemento == null) escolherElemento(it);
        else registar(it.aluno, it.materia != null ? it.materia : materia, it.elemento, it.nota);
    }

    private void escolherAluno(final Parser.Item it, final boolean soFoco) {
        final Store.Turma t = store.turma(turmaId);
        if (t == null) return;
        final List<String> op = new ArrayList<>();
        boolean podeAcrescentar = it.falado != null && !it.falado.isEmpty() && it.candidatos.isEmpty()
                && !"sem aluno".equals(it.problema);
        if (podeAcrescentar) op.add("➕ Acrescentar «" + it.falado + "» à turma");
        op.addAll(it.candidatos.isEmpty() ? t.alunos : it.candidatos);
        final boolean primeiroENovo = podeAcrescentar;
        new AlertDialog.Builder(this)
                .setTitle(soFoco ? "Qual aluno?" : "«" + it.falado + "» — nota " + it.nota + ": qual aluno?")
                .setItems(op.toArray(new String[0]), (d, w) -> {
                    String escolhido;
                    if (primeiroENovo && w == 0) {
                        escolhido = it.falado;
                        if (!t.alunos.contains(escolhido)) t.alunos.add(escolhido);
                        Storage.save(this, store);
                        atualizarSpinners();
                    } else {
                        escolhido = op.get(w);
                    }
                    foco = escolhido;
                    atualizarFoco();
                    if (soFoco) {
                        vistaPorAluno = true;
                        atualizarNotas();
                        return;
                    }
                    it.aluno = escolhido;
                    resolverItem(it);
                })
                .setNegativeButton("Ignorar", null)
                .show();
    }

    private void escolherElemento(final Parser.Item it) {
        final String mat = it.materia != null ? it.materia : materia;
        final List<String> els = new ArrayList<>();
        final List<String> mats = new ArrayList<>();
        final List<String> rotulos = new ArrayList<>();
        if (!it.candElementos.isEmpty()) {
            for (int i = 0; i < it.candElementos.size(); i++) {
                String m = i < it.candMaterias.size() ? it.candMaterias.get(i) : mat;
                els.add(it.candElementos.get(i));
                mats.add(m);
                rotulos.add(it.candElementos.get(i) + "  (" + m + ")");
            }
        } else {
            for (Store.Materia m : store.materias) {
                if (mat != null && !m.nome.equals(mat)) continue;
                for (String e : m.elementos) { els.add(e); mats.add(m.nome); rotulos.add(e); }
            }
        }
        if (els.isEmpty()) {
            toast("Diga ou escolha primeiro a matéria.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(it.aluno + " — nota " + it.nota + ": qual elemento?")
                .setItems(rotulos.toArray(new String[0]), (d, w) -> {
                    it.elemento = els.get(w);
                    it.materia = mats.get(w);
                    resolverItem(it);
                })
                .setNegativeButton("Ignorar", null)
                .show();
    }

    private void adicionarLinha(String s, int cor, Runnable toque) {
        Linha l = new Linha();
        l.texto = new SimpleDateFormat("HH:mm", Locale.ROOT).format(new Date()) + "  " + s;
        l.cor = cor;
        l.toque = toque;
        registo.add(0, l);
        while (registo.size() > 40) registo.remove(registo.size() - 1);
        mostrarRegisto();
    }

    private void mostrarRegisto() {
        boxRegisto.removeAllViews();
        if (registo.isEmpty()) {
            TextView v = texto("Ainda nada registado nesta sessão.", 14, C_SUAVE, false);
            v.setPadding(0, dp(6), 0, 0);
            boxRegisto.addView(v);
            return;
        }
        int max = Math.min(registo.size(), 8);
        for (int i = 0; i < max; i++) {
            Linha l = registo.get(i);
            TextView v = texto(l.texto, i == 0 ? 16 : 14, l.cor, i == 0);
            v.setPadding(0, dp(5), 0, dp(5));
            if (l.toque != null) {
                final Runnable r = l.toque;
                v.setOnClickListener(x -> r.run());
            }
            boxRegisto.addView(v);
        }
    }

    // =====================================================================
    // Reconhecimento de voz

    private Intent intentVoz() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-PT");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
        return i;
    }

    private void estadoParado() {
        tvEstado.setText("Diga a matéria, o elemento e as notas, por exemplo: «Andebol, desmarcação: Jesus 4, Gabriel 2». "
                + "Depois basta «Maria 5, Tiago 3». Para um aluno em vários elementos: «Jesus pega 3, remate em salto 5». "
                + "«anular» corrige o último.");
    }

    private void comecarOuvir() {
        if (store.turma(turmaId) == null) {
            dialogoTurma(null);
            return;
        }
        if (store.materia(materia) == null) {
            dialogoMaterias();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Reconhecimento de voz indisponível")
                    .setMessage("Este telemóvel não tem um serviço de reconhecimento de voz ativo. "
                            + "Instale ou atualize a aplicação Google e confirme que o português (Portugal) "
                            + "está disponível nas definições de voz.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        aOuvir = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        silenciar(true);
        iniciarEscuta();
        btOuvir.setText("A ouvir… toque para parar");
        btOuvir.setBackground(fundo(C_OUVIR, 10, 0));
        tvEstado.setText("A ouvir. Diga o nome do aluno e a nota (1 a 5).");
    }

    private void pararOuvir() {
        aOuvir = false;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) {
            try {
                recognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        handler.postDelayed(() -> silenciar(false), 600);
        btOuvir.setText("Começar a ouvir");
        btOuvir.setBackground(fundo(C_PRINCIPAL, 10, 0));
        estadoParado();
    }

    private void iniciarEscuta() {
        if (!aOuvir) return;
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(this);
            }
            recognizer.startListening(intentVoz());
        } catch (Exception e) {
            reiniciarRecognizer();
        }
    }

    private void reiniciarRecognizer() {
        if (recognizer != null) {
            try {
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
        if (aOuvir) handler.postDelayed(this::iniciarEscuta, 500);
    }

    /** Silencia os "bips" do reconhecimento enquanto está a ouvir. */
    private void silenciar(boolean sim) {
        if (sim && !somDesligado) return;
        if (silenciado == sim) return;
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;
            int dir = sim ? AudioManager.ADJUST_MUTE : AudioManager.ADJUST_UNMUTE;
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0);
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, dir, 0);
            silenciado = sim;
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_MIC) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) comecarOuvir();
            else toast("Sem acesso ao microfone não é possível ditar as notas.");
        }
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        if (aOuvir) tvEstado.setText("A ouvir. Diga o nome do aluno e a nota (1 a 5).");
    }

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onRmsChanged(float rmsdB) {
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
    }

    @Override
    public void onEndOfSpeech() {
    }

    @Override
    public void onError(int error) {
        if (!aOuvir) return;
        switch (error) {
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                pararOuvir();
                toast("Sem permissão para usar o microfone.");
                return;
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                tvEstado.setText("Sem internet: a tentar de novo… (pode transferir o português para usar sem internet nas definições de voz)");
                handler.postDelayed(this::iniciarEscuta, 1500);
                return;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
            case SpeechRecognizer.ERROR_CLIENT:
            case SpeechRecognizer.ERROR_SERVER:
                reiniciarRecognizer();
                return;
            default:
                // silêncio ou fala não percebida: continua a ouvir
                handler.postDelayed(this::iniciarEscuta, 150);
        }
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> l = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (l != null && !l.isEmpty()) {
            tvOuvido.setText("«" + l.get(0) + "»");
            processar(new ArrayList<>(new LinkedHashSet<>(l)));
        }
        handler.postDelayed(this::iniciarEscuta, 150);
    }

    @Override
    public void onPartialResults(Bundle partial) {
        ArrayList<String> l = partial == null ? null : partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (l != null && !l.isEmpty() && !l.get(0).trim().isEmpty()) tvOuvido.setText("«" + l.get(0) + "…»");
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
    }

    // =====================================================================
    // Turmas e matérias

    private void dialogoListaTurmas() {
        final List<Store.Turma> ts = store.turmasOrdenadas();
        String[] nomes = new String[ts.size()];
        for (int i = 0; i < ts.size(); i++) nomes[i] = ts.get(i).label() + "  ·  " + ts.get(i).alunos.size() + " alunos";
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Turmas")
                .setPositiveButton("Nova turma", (d, w) -> dialogoTurma(null))
                .setNegativeButton("Fechar", null);
        if (nomes.length > 0) b.setItems(nomes, (d, w) -> dialogoTurma(ts.get(w)));
        else b.setMessage("Ainda não há turmas.");
        b.show();
    }

    private EditText campo(String dica, int tipo) {
        EditText e = new EditText(this);
        e.setHint(dica);
        e.setInputType(tipo);
        return e;
    }

    private void dialogoTurma(final Store.Turma existente) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        LinearLayout lin = new LinearLayout(this);
        final EditText ano = campo("Ano (ex.: 7)", InputType.TYPE_CLASS_TEXT);
        final EditText nome = campo("Turma (ex.: A)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        lin.addView(ano, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        lin.addView(nome, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        l.addView(lin);
        TextView info = texto("Alunos, um por linha (pela ordem do número):", 13, C_SUAVE, false);
        info.setPadding(0, dp(10), 0, 0);
        l.addView(info);
        final EditText alunos = campo("Jesus Ferreira\nGabriel Santos\n…",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        alunos.setMinLines(6);
        alunos.setMaxLines(12);
        alunos.setGravity(Gravity.TOP | Gravity.START);
        l.addView(alunos);
        TextView dica = texto("Pode colar a lista copiada de outro sítio. Se dois alunos tiverem o mesmo primeiro nome, "
                + "diga também o apelido. Se deixar a lista vazia, os nomes que ditar são acrescentados.", 12, C_SUAVE, false);
        dica.setPadding(0, dp(6), 0, dp(6));
        l.addView(dica);

        if (existente != null) {
            ano.setText(existente.ano);
            nome.setText(existente.nome);
            alunos.setText(String.join("\n", existente.alunos));
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(l);

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(existente == null ? "Nova turma" : "Turma " + existente.label())
                .setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    String a = ano.getText().toString().trim().replace(".º", "").replace("º", "");
                    String n = nome.getText().toString().trim();
                    if (a.isEmpty() && n.isEmpty()) {
                        toast("Indique o ano e a turma.");
                        return;
                    }
                    List<String> novos = new ArrayList<>();
                    for (String s : alunos.getText().toString().split("\\r?\\n")) {
                        String x = s.trim().replaceAll("^\\d+[.)\\-\\s]+", "").replaceAll("\\s+", " ");
                        if (!x.isEmpty() && !novos.contains(x)) novos.add(x);
                    }
                    Store.Turma t = existente;
                    if (t == null) {
                        t = new Store.Turma();
                        t.id = UUID.randomUUID().toString();
                        store.turmas.add(t);
                    } else if (t.alunos.size() == novos.size()) {
                        // mesma quantidade: nomes alterados na mesma posição são correções
                        for (int i = 0; i < novos.size(); i++)
                            if (!t.alunos.get(i).equals(novos.get(i)) && !t.alunos.contains(novos.get(i)))
                                store.renomearAluno(t.id, t.alunos.get(i), novos.get(i));
                    }
                    t.ano = a;
                    t.nome = n;
                    t.alunos = novos;
                    turmaId = t.id;
                    foco = null;
                    Storage.save(this, store);
                    guardarPrefs();
                    atualizarSpinners();
                    atualizarFoco();
                    atualizarNotas();
                })
                .setNegativeButton("Cancelar", null);
        if (existente != null) {
            b.setNeutralButton("Apagar", (d, w) -> new AlertDialog.Builder(this)
                    .setTitle("Apagar a turma " + existente.label() + "?")
                    .setMessage("As notas desta turma também são apagadas. Exporte o Excel antes, se precisar delas.")
                    .setPositiveButton("Apagar", (d2, w2) -> {
                        store.removeTurma(existente.id);
                        foco = null;
                        validarSelecao();
                        Storage.save(this, store);
                        guardarPrefs();
                        atualizarSpinners();
                        atualizarFoco();
                        atualizarNotas();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show());
        }
        b.show();
    }

    private void dialogoMaterias() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(texto("Cada matéria começa por «#», com a área entre parênteses retos "
                + "(JDC, GIN…). Por baixo, um elemento por linha.", 13, C_SUAVE, false));
        final EditText e = campo("", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setMinLines(8);
        e.setMaxLines(18);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setTextSize(14);
        e.setText(Store.materiasParaTexto(store.materias));
        l.addView(e);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this)
                .setTitle("Matérias e elementos")
                .setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    List<Store.Materia> novas = Store.textoParaMaterias(e.getText().toString());
                    if (novas.isEmpty()) {
                        toast("A lista ficou vazia; nada foi alterado.");
                        return;
                    }
                    store.materias = novas;
                    validarSelecao();
                    Storage.save(this, store);
                    guardarPrefs();
                    atualizarSpinners();
                    atualizarNotas();
                })
                .setNeutralButton("Repor fichas", (d, w) -> new AlertDialog.Builder(this)
                        .setTitle("Repor as matérias das fichas?")
                        .setMessage("A lista volta às matérias e elementos originais. As notas já dadas mantêm-se.")
                        .setPositiveButton("Repor", (d2, w2) -> {
                            store.materias = Store.materiasPadrao();
                            validarSelecao();
                            Storage.save(this, store);
                            guardarPrefs();
                            atualizarSpinners();
                            atualizarNotas();
                        })
                        .setNegativeButton("Cancelar", null)
                        .show())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void guardarPrefs() {
        prefs.edit()
                .putString("turma", turmaId)
                .putString("materia", materia)
                .putString("elemento", elemento)
                .putBoolean("semSom", somDesligado)
                .apply();
    }

    // =====================================================================
    // Excel

    private void exportar() {
        if (store.turmas.isEmpty()) {
            toast("Ainda não há turmas para exportar.");
            return;
        }
        String data = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(XLSX);
        i.putExtra(Intent.EXTRA_TITLE, "Avaliacao_EF_" + data + ".xlsx");
        try {
            startActivityForResult(i, REQ_EXPORTAR);
        } catch (ActivityNotFoundException e) {
            toast("Não foi possível abrir o seletor de ficheiros.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_EXPORTAR || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        boolean ok = false;
        String erro = "";
        for (String modo : new String[]{"wt", "w"}) {
            try (OutputStream os = getContentResolver().openOutputStream(uri, modo)) {
                if (os == null) continue;
                ExcelExport.write(store, os);
                ok = true;
                break;
            } catch (Exception e) {
                erro = e.getMessage();
            }
        }
        if (!ok) {
            toast("Não foi possível guardar o Excel: " + erro);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Excel guardado")
                .setMessage("Tem uma folha por turma com os elementos de cada matéria, a média por matéria, "
                        + "as matérias atingidas e o nível de Atividades Físicas no 1.º e 2.º semestre. "
                        + "A média mínima para contar uma matéria pode ser alterada na folha «Critérios».")
                .setPositiveButton("Partilhar", (d, w) -> {
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType(XLSX);
                    s.putExtra(Intent.EXTRA_STREAM, uri);
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(s, "Partilhar Excel"));
                })
                .setNeutralButton("Abrir", (d, w) -> {
                    Intent v = new Intent(Intent.ACTION_VIEW);
                    v.setDataAndType(uri, XLSX);
                    v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivity(v);
                    } catch (ActivityNotFoundException ex) {
                        toast("Instale o Excel ou o Google Sheets para abrir o ficheiro.");
                    }
                })
                .setNegativeButton("OK", null)
                .show();
    }

    // =====================================================================
    // Menu

    private static final int M_EXCEL = 1, M_TURMAS = 2, M_MAT = 3, M_SOM = 4, M_AJUDA = 5, M_ATUALIZAR = 6;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, M_EXCEL, 0, "Exportar Excel");
        menu.add(0, M_TURMAS, 1, "Turmas e alunos");
        menu.add(0, M_MAT, 2, "Matérias e elementos");
        MenuItem som = menu.add(0, M_SOM, 3, "Silenciar o «bip» ao ouvir");
        som.setCheckable(true);
        som.setChecked(somDesligado);
        menu.add(0, M_ATUALIZAR, 4, "Procurar atualizações (versão " + Atualizador.versaoAtual() + ")");
        menu.add(0, M_AJUDA, 5, "Ajuda");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case M_EXCEL:
                exportar();
                return true;
            case M_TURMAS:
                dialogoListaTurmas();
                return true;
            case M_ATUALIZAR:
                procurarAtualizacao(true);
                return true;
            case M_MAT:
                dialogoMaterias();
                return true;
            case M_SOM:
                somDesligado = !somDesligado;
                item.setChecked(somDesligado);
                guardarPrefs();
                if (!somDesligado) silenciar(false);
                else if (aOuvir) silenciar(true);
                return true;
            case M_AJUDA:
                new AlertDialog.Builder(this)
                        .setTitle("Como usar")
                        .setMessage("1. Crie a turma (ano, letra e lista de alunos).\n"
                                + "2. Toque em «Começar a ouvir». Não precisa de escolher nada no ecrã: "
                                + "a matéria e o elemento são reconhecidos no que diz.\n\n"
                                + "Avaliar a turma num elemento:\n«Andebol, desmarcação: Jesus 4, Gabriel 2» "
                                + "e depois só «Maria João 5, Tiago 3»\n\n"
                                + "Mudar de elemento: «pega: Jesus 3, Henrique 4»\n"
                                + "Mudar de matéria: «Basquetebol, passe: Luana 4»\n\n"
                                + "Avaliar um aluno em vários elementos:\n«Jesus pega 3, remate em salto 5, interceção 2»\n\n"
                                + "Elemento que não está na lista: diga a matéria antes, ex.: «Voleibol, Jesus serviço por cima 4». "
                                + "O elemento é criado e aparece no Excel.\n"
                                + "Matéria nova: «matéria natação, Jesus crol 4».\n\n"
                                + "Corrigir: «anular» ou o botão «Anular último». Também pode tocar nos números 1 a 5.\n"
                                + "Linhas a vermelho não foram percebidas: toque nelas para escolher o aluno ou o elemento.\n\n"
                                + "Escala: 1 não faz · 2 faz mal · 3 executa com dificuldade · 4 executa · 5 executa muito bem.\n\n"
                                + "«Exportar Excel» cria o ficheiro com todas as turmas, as médias por matéria e o nível "
                                + "de Atividades Físicas pela tabela da ficha (1.º e 2.º semestre).")
                        .setPositiveButton("OK", null)
                        .show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
