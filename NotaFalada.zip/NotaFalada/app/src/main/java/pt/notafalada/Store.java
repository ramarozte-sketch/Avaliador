package pt.notafalada;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Dados da aplicação: turmas, alunos, matérias/elementos e notas. Java puro (sem Android). */
public class Store {

    public static final String[] DESCRITORES = {
            "", "Não faz", "Faz mal", "Executa com dificuldade", "Executa", "Executa muito bem"
    };

    public static class Turma {
        public String id;
        public String ano;      // ex.: "7"
        public String nome;     // ex.: "A"
        public List<String> alunos = new ArrayList<>();

        public String label() {
            String a = ano == null ? "" : ano.trim();
            String n = nome == null ? "" : nome.trim();
            if (a.isEmpty()) return n;
            return a + ".º " + n;
        }
    }

    /** Uma matéria (ex.: Andebol) com a sua área (JDC, GIN, …) e os elementos avaliados. */
    public static class Materia {
        public String nome;
        public String area = "";
        public List<String> elementos = new ArrayList<>();

        public Materia() { }

        public Materia(String nome, String area, String... elementos) {
            this.nome = nome;
            this.area = area;
            this.elementos.addAll(Arrays.asList(elementos));
        }
    }

    public static class Nota {
        public String turmaId;
        public String aluno;
        public String materia;
        public String elemento;
        public int valor;
        public long data;

        public Nota copy() {
            Nota n = new Nota();
            n.turmaId = turmaId; n.aluno = aluno; n.materia = materia; n.elemento = elemento;
            n.valor = valor; n.data = data;
            return n;
        }

        boolean e(String t, String a, String m, String el) {
            return turmaId.equals(t) && aluno.equals(a) && materia.equals(m) && elemento.equals(el);
        }
    }

    public List<Turma> turmas = new ArrayList<>();
    public List<Materia> materias = new ArrayList<>();
    /** Uma nota (a mais recente) por turma + aluno + matéria + elemento. */
    public List<Nota> notas = new ArrayList<>();

    /** Matérias e elementos das fichas de autoavaliação do 7.º ano (nível introdutório). */
    public static List<Materia> materiasPadrao() {
        List<Materia> l = new ArrayList<>();
        l.add(new Materia("Andebol", "JDC",
                "Desmarcação", "Pega", "Passe de ombro", "Drible de progressão", "Remate em apoio",
                "Remate em salto", "Interceção", "Impede ou dificulta passe, drible e remate"));
        l.add(new Materia("Basquetebol", "JDC",
                "Receção em posição facial ao cesto", "Lançamento parado perto do cesto", "Lançamento na passada",
                "Drible de progressão", "Drible de proteção", "Passe", "Desmarcação", "Atitude defensiva",
                "Participação no ressalto"));
        l.add(new Materia("Voleibol", "JDC",
                "Serviço por baixo", "Receção por cima ou em manchete", "Passe e manchete com número limitado de toques"));
        l.add(new Materia("Futebol", "JDC",
                "Remate", "Passe", "Receção", "Condução de bola", "Desmarcação", "Marcação"));
        l.add(new Materia("Hóquei em campo", "JDC",
                "Condução de bola", "Receção à esquerda e à direita", "Passe empurrado à esquerda e à direita",
                "Remate empurrado", "Desmarcação", "Marcação"));
        l.add(new Materia("Ginástica de solo", "GIN",
                "Cambalhota à frente pés juntos", "Cambalhota à frente pernas afastadas",
                "Cambalhota à retaguarda pernas afastadas", "Cambalhota à retaguarda pés juntos",
                "Passagem por pino", "Subida para pino", "Roda no plinto", "Avião", "Sequência de habilidades"));
        l.add(new Materia("Ginástica de aparelhos", "GIN",
                "Salto ao eixo no boque longitudinal", "Salto ao eixo no boque", "Salto entre mãos",
                "Cambalhota à frente no plinto", "Salto em extensão no minitrampolim",
                "Salto engrupado no minitrampolim", "Salto encarpado no minitrampolim",
                "Salto meia pirueta no minitrampolim", "Marcha à frente e atrás na trave",
                "Marcha na ponta dos pés na trave", "Salto a pés juntos na trave"));
        l.add(new Materia("Ginástica acrobática", "GIN",
                "Prancha facial sobre base", "Base sentado volante pino", "Base perna fletida volante equilíbrio coxa",
                "Cambalhota à frente a dois", "Base de joelhos volante equilíbrio ombros",
                "2 bases deitados volante prancha", "2 bases afundo volante equilíbrio coxas",
                "2 bases pega cotovelos volante voo prancha", "2 bases joelhos volante pino sobre coxas"));
        l.add(new Materia("Badminton", "RAQ",
                "Posição base", "Pega", "Serviço curto e comprido", "Clear", "Lob", "Deslocamentos"));
        l.add(new Materia("Atletismo", "ATL",
                "Velocidade 40 m", "Estafetas 4x50 m", "Corrida com pequenos obstáculos", "Salto em comprimento",
                "Salto em altura tesoura", "Lançamento do peso"));
        l.add(new Materia("Danças sociais", "DAN",
                "Merengue passos no lugar progressivos e laterais", "Merengue passos cruzados",
                "Rumba passos à frente e atrás com voltas", "Rumba quadrada passo básico volta e contravolta", "Ritmo"));
        l.add(new Materia("Danças tradicionais", "DAN",
                "Regadinho passo de passeio saltado e saltitado", "Ritmo"));
        return l;
    }

    public Turma turma(String id) {
        if (id == null) return null;
        for (Turma t : turmas) if (t.id.equals(id)) return t;
        return null;
    }

    public Materia materia(String nome) {
        if (nome == null) return null;
        for (Materia m : materias) if (m.nome.equals(nome)) return m;
        return null;
    }

    public Nota nota(String turmaId, String aluno, String materia, String elemento) {
        for (Nota n : notas) if (n.e(turmaId, aluno, materia, elemento)) return n;
        return null;
    }

    /** Grava a nota e devolve a anterior (cópia) ou null, para poder anular. */
    public Nota setNota(String turmaId, String aluno, String materia, String elemento, int valor, long data) {
        Nota n = nota(turmaId, aluno, materia, elemento);
        Nota anterior = n == null ? null : n.copy();
        if (n == null) {
            n = new Nota();
            n.turmaId = turmaId; n.aluno = aluno; n.materia = materia; n.elemento = elemento;
            notas.add(n);
        }
        n.valor = valor;
        n.data = data;
        return anterior;
    }

    public void removeNota(String turmaId, String aluno, String materia, String elemento) {
        for (int i = notas.size() - 1; i >= 0; i--) if (notas.get(i).e(turmaId, aluno, materia, elemento)) notas.remove(i);
    }

    public void renomearAluno(String turmaId, String antigo, String novo) {
        for (Nota n : notas) if (n.turmaId.equals(turmaId) && n.aluno.equals(antigo)) n.aluno = novo;
    }

    public void removeTurma(String id) {
        for (int i = turmas.size() - 1; i >= 0; i--) if (turmas.get(i).id.equals(id)) turmas.remove(i);
        for (int i = notas.size() - 1; i >= 0; i--) if (notas.get(i).turmaId.equals(id)) notas.remove(i);
    }

    /** Texto editável: "# Matéria [ÁREA]" seguido de um elemento por linha. */
    public static String materiasParaTexto(List<Materia> ms) {
        StringBuilder b = new StringBuilder();
        for (Materia m : ms) {
            if (b.length() > 0) b.append("\n");
            b.append("# ").append(m.nome);
            if (m.area != null && !m.area.isEmpty()) b.append(" [").append(m.area).append("]");
            b.append("\n");
            for (String e : m.elementos) b.append(e).append("\n");
        }
        return b.toString();
    }

    public static List<Materia> textoParaMaterias(String texto) {
        List<Materia> l = new ArrayList<>();
        Materia atual = null;
        for (String linha : texto.split("\\r?\\n")) {
            String s = linha.trim().replaceAll("\\s+", " ");
            if (s.isEmpty()) continue;
            if (s.startsWith("#")) {
                s = s.substring(1).trim();
                String area = "";
                int a = s.lastIndexOf('['), f = s.lastIndexOf(']');
                if (a >= 0 && f > a) {
                    area = s.substring(a + 1, f).trim().toUpperCase();
                    s = (s.substring(0, a) + s.substring(f + 1)).trim();
                }
                if (s.isEmpty()) continue;
                atual = null;
                for (Materia m : l) if (m.nome.equalsIgnoreCase(s)) atual = m;
                if (atual == null) {
                    atual = new Materia();
                    atual.nome = s;
                    l.add(atual);
                }
                atual.area = area;
            } else {
                if (atual == null) {
                    atual = new Materia();
                    atual.nome = "Geral";
                    l.add(atual);
                }
                if (!atual.elementos.contains(s)) atual.elementos.add(s);
            }
        }
        return l;
    }

    /** Ordena as turmas por ano e depois por letra. */
    public List<Turma> turmasOrdenadas() {
        List<Turma> l = new ArrayList<>(turmas);
        l.sort((a, b) -> {
            int c = Integer.compare(num(a.ano), num(b.ano));
            if (c != 0) return c;
            c = String.valueOf(a.ano).compareTo(String.valueOf(b.ano));
            if (c != 0) return c;
            return String.valueOf(a.nome).compareToIgnoreCase(String.valueOf(b.nome));
        });
        return l;
    }

    private static int num(String s) {
        if (s == null) return 999;
        StringBuilder d = new StringBuilder();
        for (char ch : s.toCharArray()) if (Character.isDigit(ch)) d.append(ch); else if (d.length() > 0) break;
        if (d.length() == 0) return 999;
        try { return Integer.parseInt(d.toString()); } catch (NumberFormatException e) { return 999; }
    }
}
