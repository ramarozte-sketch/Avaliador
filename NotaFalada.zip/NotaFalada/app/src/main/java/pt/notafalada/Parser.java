package pt.notafalada;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Interpreta o texto ditado. Exemplos:
 *   "Jesus 4, Gabriel 2"                       -> nota no elemento atual
 *   "Jesus desmarcação 4 pega 3 remate em salto 5" -> várias notas para o mesmo aluno
 *   "aluno Jesus"                              -> fixa o aluno; depois "pega 3, passe de ombro 4"
 *   "elemento remate em apoio" / "matéria basquetebol"
 *   "anular"                                   -> anula o último registo
 */
public class Parser {

    public static class Item {
        public String falado;          // o que foi ouvido (nome e/ou elemento)
        public String aluno;           // aluno reconhecido (null = não reconhecido)
        public String materia;
        public String elemento;        // elemento reconhecido (null = não reconhecido)
        public int nota;
        public String problema;        // null se tudo bem
        public List<String> candidatos = new ArrayList<>(); // alunos possíveis, se ambíguo
        public List<String> candElementos = new ArrayList<>(); // elementos possíveis, se ambíguo
        public boolean alunoNovo;      // turma sem lista: nome a acrescentar
    }

    public static class Result {
        public String texto;
        public List<Item> itens = new ArrayList<>();
        public String materia;      // matéria pedida por comando
        public String elemento;     // elemento pedido por comando
        public String foco;         // aluno em foco no fim da frase
        public boolean focoMudou;
        public boolean anular;
        java.util.Map<String, String> orig = new java.util.HashMap<>();

        public int score() {
            int s = 0;
            for (Item i : itens) s += i.problema == null ? 10 : -4;
            if (materia != null) s += 3;
            if (elemento != null) s += 3;
            if (focoMudou && foco != null) s += 3;
            if (anular) s += 3;
            return s;
        }

        public boolean vazio() {
            return itens.isEmpty() && materia == null && elemento == null && !focoMudou && !anular;
        }
    }

    // palavras que não fazem parte do nome do aluno
    private static final Set<String> IGNORAR_NOME = new HashSet<>(Arrays.asList(
            "e", "nota", "notas", "tem", "teve", "o", "a", "ao", "com", "valor", "valores", "ficou", "fica",
            "leva", "levou", "aluno", "aluna", "para", "virgula", "ponto", "no", "na", "em"));
    private static final Set<String> LIGACOES = new HashSet<>(Arrays.asList("da", "de", "do", "das", "dos"));
    // palavras ignoradas ao comparar elementos
    private static final Set<String> STOP_ELEM = new HashSet<>(Arrays.asList(
            "e", "de", "do", "da", "dos", "das", "em", "a", "o", "as", "os", "ao", "aos", "com", "por", "no", "na",
            "nos", "nas", "ou", "sobre", "para", "um", "uma", "nota", "tem", "teve", "ficou", "fica", "valor",
            "virgula", "ponto", "x"));

    private static final Set<String> CMD_MATERIA = new HashSet<>(Arrays.asList(
            "materia", "materias", "modalidade", "modalidades"));
    private static final Set<String> CMD_ELEMENTO = new HashSet<>(Arrays.asList(
            "elemento", "elementos", "conteudo", "conteudos", "exercicio", "exercicios", "habilidade", "habilidades"));
    private static final Set<String> CMD_ALUNO = new HashSet<>(Arrays.asList("aluno", "aluna"));
    private static final Set<String> CMD_ANULAR = new HashSet<>(Arrays.asList(
            "anular", "anula", "desfazer", "desfaz", "apagar", "apaga", "cancelar", "cancela"));

    // =================================================================== texto

    public static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.toLowerCase(Locale.ROOT).trim();
    }

    public static List<String> tokens(String s) {
        String n = norm(s)
                .replace("º", " ").replace("ª", " ")
                .replaceAll("(\\d+)", " $1 ")
                .replaceAll("[^a-z0-9]+", " ")
                .trim();
        List<String> t = new ArrayList<>();
        if (n.isEmpty()) return t;
        t.addAll(Arrays.asList(n.split("\\s+")));
        return t;
    }

    /** 1..5 se for uma nota, 0 se for outro número, -1 se não for número. */
    static int numero(String tok) {
        switch (tok) {
            case "1": case "um": case "uma": return 1;
            case "2": case "dois": case "duas": return 2;
            case "3": case "tres": return 3;
            case "4": case "quatro": return 4;
            case "5": case "cinco": return 5;
            default:
                if (tok.matches("\\d+")) return 0;
                return -1;
        }
    }

    static String canon(String tok) {
        int n = numero(tok);
        return n >= 1 ? String.valueOf(n) : tok;
    }

    // =================================================================== parse

    public static Result parse(String texto, List<String> alunos, List<Store.Materia> materias,
                               String materiaAtual, String elementoAtual, String focoAtual) {
        Result r = new Result();
        r.texto = texto;
        r.foco = focoAtual;
        if (alunos == null) alunos = new ArrayList<>();
        if (materias == null) materias = new ArrayList<>();
        List<String> t = tokens(texto);
        if (t.isEmpty()) return r;
        for (String w : texto.split("[^\\p{L}\\p{N}]+")) if (!w.isEmpty()) r.orig.put(norm(w), w);

        if (CMD_ANULAR.contains(t.get(0))) {
            r.anular = true;
            return r;
        }

        String materia = materiaAtual;
        String elemento = elementoAtual;
        int i = 0;
        // ----- comandos no início da frase (podem encadear-se) -----
        while (i < t.size()) {
            String w = t.get(i);
            if (CMD_MATERIA.contains(w)) {
                List<String> nomes = new ArrayList<>();
                for (Store.Materia m : materias) nomes.add(m.nome);
                Match mm = melhorPrefixo(t, i + 1, nomes, null, false);
                if (mm.valor == null) return r;
                materia = mm.valor;
                r.materia = materia;
                Store.Materia mat = achar(materias, materia);
                elemento = mat != null && !mat.elementos.isEmpty() ? mat.elementos.get(0) : null;
                i = i + 1 + mm.usados;
            } else if (CMD_ELEMENTO.contains(w)) {
                // primeiro na matéria atual, depois em todas
                Store.Materia mat = achar(materias, materia);
                Match me = mat == null ? new Match() : melhorPrefixo(t, i + 1, mat.elementos, null, false);
                String matDoElem = materia;
                if (me.valor == null || me.score < 60) {
                    for (Store.Materia m : materias) {
                        if (m == mat) continue;
                        Match o = melhorPrefixo(t, i + 1, m.elementos, null, false);
                        if (o.valor != null && o.score > me.score + 10) { me = o; matDoElem = m.nome; }
                    }
                }
                if (me.valor == null) return r;
                elemento = me.valor;
                r.elemento = elemento;
                if (matDoElem != null && !matDoElem.equals(materia)) { materia = matDoElem; r.materia = materia; }
                i = i + 1 + me.usados;
            } else if (CMD_ALUNO.contains(w) && !alunos.isEmpty() && i + 1 < t.size() && numero(t.get(i + 1)) < 0) {
                Match ma = melhorPrefixo(t, i + 1, alunos, null, true);
                r.focoMudou = true;
                if (ma.valor != null && ma.empates.size() <= 1) {
                    r.foco = ma.valor;
                    i = i + 1 + ma.usados;
                } else {
                    r.foco = null;
                    Item it = new Item();
                    it.falado = capitalizar(String.join(" ", limparNome(t.subList(i + 1, Math.min(t.size(), i + 3)))));
                    it.problema = ma.empates.size() > 1 ? "ambíguo" : "aluno não reconhecido";
                    it.candidatos.addAll(ma.empates);
                    r.itens.add(it);
                    return r;
                }
            } else break;
        }

        Store.Materia mat = achar(materias, materia);
        List<String> elems = mat == null ? new ArrayList<>() : mat.elementos;

        // ----- pares (nome/elemento + nota) -----
        List<String> seg = new ArrayList<>();
        for (; i < t.size(); i++) {
            String tok = t.get(i);
            int n = numero(tok);
            if (n >= 1) {
                String prox = i + 1 < t.size() ? t.get(i + 1) : null;
                if (!seg.isEmpty() && continuaElemento(tok, prox, elems)) { seg.add(canon(tok)); continue; }
                if (seg.isEmpty() && prox != null && continuaElemento(tok, prox, elems)) { seg.add(canon(tok)); continue; }
                if (temConteudo(seg)) {
                    Item it = resolver(seg, n, alunos, elems, materia, elemento, r);
                    r.itens.add(it);
                }
                seg.clear();
            } else if (n == 0) {
                // número fora da escala: só fica se fizer parte de um elemento (ex.: "velocidade 40")
                boolean parte = false;
                for (String e : elems) if (tokens(e).contains(tok)) parte = true;
                if (parte) seg.add(tok); else seg.clear();
            } else {
                seg.add(tok);
            }
        }
        return r;
    }

    private static boolean temConteudo(List<String> seg) {
        for (String s : seg) if (!IGNORAR_NOME.contains(s) && !STOP_ELEM.contains(s)) return true;
        return false;
    }

    private static Store.Materia achar(List<Store.Materia> ms, String nome) {
        if (nome == null) return null;
        for (Store.Materia m : ms) if (m.nome.equals(nome)) return m;
        return null;
    }

    /** O número faz parte do nome de um elemento (ex.: "2 bases…", "estafetas 4x50")? */
    static boolean continuaElemento(String numTok, String prox, List<String> elems) {
        if (prox == null) return false;
        String c = canon(numTok);
        for (String e : elems) {
            List<String> et = tokens(e);
            for (int j = 0; j + 1 < et.size(); j++)
                if (canon(et.get(j)).equals(c) && parecidoOuPrefixo(et.get(j + 1), prox)) return true;
        }
        return false;
    }

    private static Item resolver(List<String> seg, int nota, List<String> alunos, List<String> elems,
                                 String materia, String elementoAtual, Result r) {
        Item it = new Item();
        it.nota = nota;
        it.materia = materia;

        Match soAluno = alunos.isEmpty() ? new Match() : matchAluno(limparNome(seg), alunos);
        Match soElem = matchElemento(seg, elems);

        if (alunos.isEmpty()) {
            // turma sem lista: os nomes ditos passam a ser alunos novos
            if (soElem.score == 100 && soElem.empates.size() == 1 && r.foco != null) {
                it.aluno = r.foco;
                it.elemento = soElem.valor;
                it.falado = bonito(seg, r);
                return it;
            }
            int corte = seg.size();
            Match e = null;
            for (int k = 1; k < seg.size(); k++) {
                Match em = matchElemento(seg.subList(k, seg.size()), elems);
                if (em.score >= 50 && em.empates.size() == 1) { corte = k; e = em; break; }
            }
            List<String> nome = limparNome(seg.subList(0, corte));
            if (nome.isEmpty()) {
                it.falado = bonito(seg, r);
                it.problema = "não reconhecido";
                return it;
            }
            it.aluno = bonito(nome, r);
            it.alunoNovo = true;
            it.elemento = e != null ? e.valor : elementoAtual;
            it.falado = it.aluno;
            if (it.elemento == null) it.problema = "sem elemento";
            r.foco = it.aluno;
            return it;
        }
        Match combA = null, combE = null;
        int combScore = 0;
        for (int k = 1; k < seg.size(); k++) {
            Match a = alunos.isEmpty() ? new Match() : matchAluno(limparNome(seg.subList(0, k)), alunos);
            Match e = matchElemento(seg.subList(k, seg.size()), elems);
            if (a.score > 0 && e.score > 0) {
                int s = (a.score + e.score) / 2 + 10;
                if (s > combScore) { combScore = s; combA = a; combE = e; }
            }
        }

        int best = Math.max(soAluno.score, Math.max(soElem.score, combScore));
        if (best == 0) {
            // nada reconhecido
            it.falado = bonito(limparNome(seg), r);
            if (it.falado.isEmpty()) it.falado = bonito(seg, r);
            it.problema = "não reconhecido";
            return it;
        }

        if (best == combScore && combA != null) {
            aplicarAluno(it, combA, r);
            aplicarElemento(it, combE);
            it.falado = bonito(seg, r);
        } else if (best == soAluno.score) {
            aplicarAluno(it, soAluno, r);
            it.elemento = elementoAtual;
            if (elementoAtual == null) it.problema = "sem elemento";
            it.falado = bonito(limparNome(seg), r);
        } else {
            aplicarElemento(it, soElem);
            it.falado = bonito(seg, r);
            if (r.foco == null) {
                if (it.problema == null) it.problema = "sem aluno";
            } else {
                it.aluno = r.foco;
            }
        }
        return it;
    }

    private static void aplicarAluno(Item it, Match a, Result r) {
        if (a.empates.size() > 1) {
            it.problema = "ambíguo";
            it.candidatos.addAll(a.empates);
        } else {
            it.aluno = a.valor;
            r.foco = a.valor;
        }
    }

    private static void aplicarElemento(Item it, Match e) {
        if (e.empates.size() > 1) {
            if (it.problema == null) it.problema = "elemento ambíguo";
            it.candElementos.addAll(e.empates);
        } else {
            it.elemento = e.valor;
        }
    }

    // =================================================================== correspondências

    static class Match {
        String valor;
        int score;
        int usados;
        List<String> empates = new ArrayList<>();
    }

    static List<String> limparNome(List<String> toks) {
        List<String> nt = new ArrayList<>();
        for (String x : toks) {
            if (LIGACOES.contains(x)) { if (!nt.isEmpty()) nt.add(x); }
            else if (!IGNORAR_NOME.contains(x) && numero(x) < 0) nt.add(x);
        }
        while (!nt.isEmpty() && LIGACOES.contains(nt.get(nt.size() - 1))) nt.remove(nt.size() - 1);
        return nt;
    }

    static Match matchAluno(List<String> falado, List<String> alunos) {
        Match m = new Match();
        if (falado.isEmpty()) return m;
        for (String a : alunos) {
            int s = pontuar(falado, a);
            if (s > m.score) { m.score = s; m.valor = a; m.empates.clear(); m.empates.add(a); }
            else if (s == m.score && s > 0) m.empates.add(a);
        }
        return m;
    }

    /** Semelhança entre as palavras ditas e o nome de um elemento (0 = nada). */
    static int pontuarElemento(List<String> falado, String elemento) {
        List<String> f = new ArrayList<>();
        for (String x : falado) if (!STOP_ELEM.contains(x)) f.add(canon(x));
        List<String> et = new ArrayList<>();
        for (String x : tokens(elemento)) if (!STOP_ELEM.contains(x)) et.add(canon(x));
        if (f.isEmpty() || et.isEmpty()) return 0;
        boolean[] coberto = new boolean[et.size()];
        int m = 0, u = 0;
        for (String w : f) {
            boolean achou = false;
            for (int j = 0; j < et.size(); j++) {
                if (parecidoOuPrefixo(et.get(j), w)) { coberto[j] = true; achou = true; }
            }
            if (achou) m++; else u++;
        }
        if (m == 0 || u > m) return 0;
        int c = 0;
        for (boolean b : coberto) if (b) c++;
        if (c == et.size() && u == 0) return 100;
        int s = Math.round(95f * c / et.size()) - 40 * u;
        if (s <= 0) s = u == 0 ? 10 : 0;
        return s;
    }

    static Match matchElemento(List<String> falado, List<String> elems) {
        Match m = new Match();
        for (String e : elems) {
            int s = pontuarElemento(falado, e);
            if (s > m.score) { m.score = s; m.valor = e; m.empates.clear(); m.empates.add(e); }
            else if (s == m.score && s > 0) m.empates.add(e);
        }
        return m;
    }

    /** Procura o melhor candidato para as palavras a partir de "de"; devolve quantas palavras usou. */
    static Match melhorPrefixo(List<String> t, int de, List<String> cands, Object unused, boolean comoAluno) {
        Match best = new Match();
        for (int L = 1; L <= 7 && de + L <= t.size(); L++) {
            List<String> sub = t.subList(de, de + L);
            if (numero(sub.get(L - 1)) >= 1 && !continuaElemento(sub.get(L - 1), de + L < t.size() ? t.get(de + L) : null, cands))
                break; // chegou a uma nota
            Match m = comoAluno ? matchAluno(limparNome(sub), cands) : matchElemento(sub, cands);
            if (m.score > 0 && m.score >= best.score) {
                m.usados = L;
                best = m;
            }
        }
        return best;
    }

    /** Pontuação de semelhança entre o nome falado e o nome do aluno na lista. */
    static int pontuar(List<String> falado, String aluno) {
        List<String> a = new ArrayList<>();
        for (String x : tokens(aluno)) if (!LIGACOES.contains(x)) a.add(x);
        List<String> f = new ArrayList<>();
        for (String x : falado) if (!LIGACOES.contains(x)) f.add(x);
        if (a.isEmpty() || f.isEmpty()) return 0;

        if (String.join(" ", a).equals(String.join(" ", f))) return 100;

        int j = 0, exatas = 0;
        boolean todas = true;
        for (String w : f) {
            boolean achou = false;
            while (j < a.size()) {
                String aw = a.get(j++);
                if (aw.equals(w)) { achou = true; exatas++; break; }
                if (parecido(aw, w)) { achou = true; break; }
            }
            if (!achou) { todas = false; break; }
        }
        if (!todas) return 0;
        if (f.size() == 1) {
            String w = f.get(0);
            if (a.get(0).equals(w)) return 60;
            if (parecido(a.get(0), w)) return 50;
            for (String aw : a) if (aw.equals(w)) return 40;
            return 30;
        }
        return 80 + f.size() * 2 + exatas;
    }

    static boolean parecidoOuPrefixo(String a, String b) {
        if (parecido(a, b)) return true;
        int min = Math.min(a.length(), b.length());
        if (min >= 4 && (a.startsWith(b) || b.startsWith(a))) return true;
        return a.length() == 1 && Character.isLetter(a.charAt(0)) && b.startsWith(a) && b.length() > 2;
    }

    static boolean parecido(String a, String b) {
        if (a.equals(b)) return true;
        String pa = fon(a), pb = fon(b);
        if (pa.equals(pb)) return true;
        int min = Math.min(pa.length(), pb.length());
        if (min < 4) return false;
        int lim = min >= 7 ? 2 : 1;
        return lev(pa, pb) <= lim;
    }

    /** Chave "fonética" simples para português. */
    static String fon(String s) {
        String x = s;
        if (x.length() > 1 && x.startsWith("h")) x = x.substring(1);
        x = x.replace("ph", "f").replace("th", "t").replace("y", "i").replace("w", "v")
                .replace("k", "c").replace("ss", "s").replace("ll", "l").replace("nn", "n")
                .replace("tt", "t").replace("z", "s").replace("qu", "c").replace("ç", "s");
        return x;
    }

    static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int c = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c);
            }
            int[] tmp = prev; prev = cur; cur = tmp;
        }
        return prev[b.length()];
    }

    /** Junta as palavras repondo os acentos tal como vieram do reconhecimento de voz. */
    static String bonito(List<String> toks, Result r) {
        List<String> out = new ArrayList<>();
        for (String x : toks) {
            String o = r == null ? null : r.orig.get(x);
            out.add(o != null ? o.toLowerCase(new Locale("pt", "PT")) : x);
        }
        return capitalizar(String.join(" ", out));
    }

    public static String capitalizar(String s) {
        StringBuilder b = new StringBuilder();
        for (String w : s.trim().split("\\s+")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            if (LIGACOES.contains(w)) b.append(w);
            else b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return b.toString();
    }

    /** Escolhe, entre as hipóteses do reconhecimento de voz, a que melhor bate com a turma e a matéria. */
    public static Result melhor(List<String> hipoteses, List<String> alunos, List<Store.Materia> materias,
                                String materiaAtual, String elementoAtual, String focoAtual) {
        Result best = null;
        for (String h : hipoteses) {
            Result r = parse(h, alunos, materias, materiaAtual, elementoAtual, focoAtual);
            if (best == null || r.score() > best.score()) best = r;
        }
        return best;
    }
}
