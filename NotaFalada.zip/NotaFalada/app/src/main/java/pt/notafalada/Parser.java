package pt.notafalada;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Interpreta o texto ditado. A matéria, o elemento e o aluno são tirados do próprio texto:
 *   "Andebol, desmarcação: Jesus 4, Gabriel 2"   -> matéria e elemento ditos antes dos nomes
 *   "Jesus 4, Gabriel 2"                         -> continua no último elemento dito
 *   "Jesus desmarcação 4, pega 3"                -> várias notas para o mesmo aluno
 *   "Basquetebol Luana passe 4 ressalto 3"       -> muda de matéria a meio
 *   "Voleibol Jesus serviço por cima 4"          -> elemento novo: é criado na matéria dita
 *   "anular"                                     -> anula o último registo
 * As palavras "matéria", "elemento" e "aluno" continuam a funcionar, mas não são precisas.
 */
public class Parser {

    public static class Item {
        public String falado;
        public String aluno;
        public String materia;
        public String elemento;
        public int nota;
        public String problema;                                  // null se tudo bem
        public List<String> candidatos = new ArrayList<>();      // alunos possíveis
        public List<String> candElementos = new ArrayList<>();   // elementos possíveis
        public List<String> candMaterias = new ArrayList<>();    // matéria de cada elemento possível
        public boolean alunoNovo;                                // a acrescentar à turma
        public boolean elementoNovo;                             // a acrescentar à matéria
    }

    public static class Result {
        public String texto;
        public List<Item> itens = new ArrayList<>();
        public String materia;      // matéria em vigor no fim (se mudou)
        public String elemento;     // elemento em vigor no fim (se mudou)
        public String foco;         // aluno em foco no fim
        public boolean focoMudou;
        public boolean anular;
        /** Elementos (e matérias) novos ditos: {matéria, elemento}. */
        public List<String[]> novos = new ArrayList<>();
        Map<String, String> orig = new HashMap<>();

        public int score() {
            int s = 0;
            for (Item i : itens) s += i.problema == null ? 10 : -4;
            if (materia != null) s += 3;
            if (elemento != null) s += 3;
            if (focoMudou && foco != null) s += 2;
            if (anular) s += 3;
            s -= novos.size() * 2;
            return s;
        }

        public boolean vazio() {
            return itens.isEmpty() && materia == null && elemento == null && !focoMudou && !anular;
        }
    }

    private static final Set<String> IGNORAR_NOME = new HashSet<>(Arrays.asList(
            "e", "nota", "notas", "tem", "teve", "o", "a", "ao", "com", "valor", "valores", "ficou", "fica",
            "leva", "levou", "aluno", "aluna", "para", "virgula", "ponto", "no", "na", "em", "agora", "depois"));
    private static final Set<String> LIGACOES = new HashSet<>(Arrays.asList("da", "de", "do", "das", "dos"));
    private static final Set<String> STOP_ELEM = new HashSet<>(Arrays.asList(
            "e", "de", "do", "da", "dos", "das", "em", "a", "o", "as", "os", "ao", "aos", "com", "por", "no", "na",
            "nos", "nas", "ou", "sobre", "para", "um", "uma", "nota", "tem", "teve", "ficou", "fica", "valor",
            "virgula", "ponto", "x", "agora", "depois", "elemento", "materia", "conteudo", "exercicio",
            "habilidade", "modalidade"));
    // palavras comuns a várias matérias: sozinhas não identificam uma matéria
    private static final Set<String> GENERICAS_MATERIA = new HashSet<>(Arrays.asList(
            "ginastica", "dancas", "danca", "jogo", "jogos", "de", "em", "a", "e"));

    private static final Set<String> CMD_MATERIA = new HashSet<>(Arrays.asList(
            "materia", "materias", "modalidade", "modalidades"));
    private static final Set<String> CMD_ELEMENTO = new HashSet<>(Arrays.asList(
            "elemento", "elementos", "conteudo", "conteudos", "exercicio", "exercicios", "habilidade", "habilidades"));
    private static final Set<String> CMD_ALUNO = new HashSet<>(Arrays.asList("aluno", "aluna"));
    private static final Set<String> CMD_ANULAR = new HashSet<>(Arrays.asList(
            "anular", "anula", "desfazer", "desfaz", "apagar", "apaga", "cancelar", "cancela"));

    // =================================================================== texto

    public static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.toLowerCase(Locale.ROOT).trim();
    }

    public static List<String> tokens(String s) {
        String n = norm(s)
                .replace("º", " ").replace("ª", " ")
                .replaceAll("(\\d+)", " $1 ")
                .replaceAll("[^a-z0-9]+", " ")
                .trim();
        List<String> t = new ArrayList<>();
        if (n.isEmpty()) return t;
        t.addAll(Arrays.asList(n.split("\\s+")));
        return t;
    }

    /** 1..5 se for uma nota, 0 se for outro número, -1 se não for número. */
    static int numero(String tok) {
        switch (tok) {
            case "1": case "um": case "uma": return 1;
            case "2": case "dois": case "duas": return 2;
            case "3": case "tres": return 3;
            case "4": case "quatro": return 4;
            case "5": case "cinco": return 5;
            default:
                if (tok.matches("\\d+")) return 0;
                return -1;
        }
    }

    static String canon(String tok) {
        int n = numero(tok);
        return n >= 1 ? String.valueOf(n) : tok;
    }

    // =================================================================== estado durante a frase

    private static class Ctx {
        List<String> alunos;
        List<Store.Materia> materias;
        String materia, elemento, foco;
        boolean materiaDita;     // a matéria foi dita nesta frase
        Result r;
    }

    // =================================================================== parse

    public static Result parse(String texto, List<String> alunos, List<Store.Materia> materias,
                               String materiaAtual, String elementoAtual, String focoAtual) {
        Result r = new Result();
        r.texto = texto;
        r.foco = focoAtual;
        Ctx c = new Ctx();
        c.alunos = alunos == null ? new ArrayList<>() : alunos;
        c.materias = materias == null ? new ArrayList<>() : new ArrayList<>(materias);
        c.materia = materiaAtual;
        c.elemento = elementoAtual;
        c.foco = focoAtual;
        c.r = r;

        List<String> t = tokens(texto);
        if (t.isEmpty()) return r;
        for (String w : texto.split("[^\\p{L}\\p{N}]+")) if (!w.isEmpty()) r.orig.put(norm(w), w);

        if (CMD_ANULAR.contains(t.get(0))) {
            r.anular = true;
            return r;
        }

        List<String> seg = new ArrayList<>();
        for (int i = 0; i < t.size(); i++) {
            String tok = t.get(i);
            int n = numero(tok);
            String prox = i + 1 < t.size() ? t.get(i + 1) : null;
            if (n >= 1) {
                if (continuaElemento(tok, prox, todosElementos(c.materias))) { seg.add(canon(tok)); continue; }
                if (temConteudo(seg)) processar(seg, n, c);
                seg.clear();
            } else if (n == 0) {
                // número fora da escala: só fica se fizer parte de um elemento (ex.: "velocidade 40")
                boolean parte = false;
                for (String e : todosElementos(c.materias)) if (tokens(e).contains(tok)) { parte = true; break; }
                if (parte) seg.add(tok); else seg.clear();
            } else {
                seg.add(tok);
            }
        }
        // resto sem nota: só muda o contexto (ex.: "Andebol, desmarcação")
        if (temConteudo(seg)) processar(seg, 0, c);

        if (c.materia != null && !c.materia.equals(materiaAtual)) r.materia = c.materia;
        if (c.elemento != null && !c.elemento.equals(elementoAtual)) r.elemento = c.elemento;
        if (r.materia != null && r.elemento == null) r.elemento = c.elemento;
        r.foco = c.foco;
        if (c.foco != null && !c.foco.equals(focoAtual)) r.focoMudou = true;
        return r;
    }

    private static List<String> todosElementos(List<Store.Materia> ms) {
        List<String> l = new ArrayList<>();
        for (Store.Materia m : ms) l.addAll(m.elementos);
        return l;
    }

    private static boolean temConteudo(List<String> seg) {
        for (String s : seg) if (!IGNORAR_NOME.contains(s) && !STOP_ELEM.contains(s)) return true;
        return false;
    }

    private static Store.Materia achar(List<Store.Materia> ms, String nome) {
        if (nome == null) return null;
        for (Store.Materia m : ms) if (m.nome.equals(nome)) return m;
        return null;
    }

    /** O número faz parte do nome de um elemento (ex.: "2 bases…", "estafetas 4x50")? */
    static boolean continuaElemento(String numTok, String prox, List<String> elems) {
        if (prox == null) return false;
        String c = canon(numTok);
        for (String e : elems) {
            List<String> et = tokens(e);
            for (int j = 0; j + 1 < et.size(); j++)
                if (canon(et.get(j)).equals(c) && parecidoOuPrefixo(et.get(j + 1), prox)) return true;
        }
        return false;
    }

    // =================================================================== um segmento (palavras antes de uma nota)

    private static void processar(List<String> segOrig, int nota, Ctx c) {
        List<String> seg = new ArrayList<>(segOrig);
        Result r = c.r;

        // ---- palavras de comando explícitas ----
        boolean pedeMateria = false, pedeElemento = false, pedeAluno = false;
        for (int k = seg.size() - 1; k >= 0; k--) {
            String w = seg.get(k);
            if (CMD_MATERIA.contains(w)) { pedeMateria = true; seg.remove(k); }
            else if (CMD_ELEMENTO.contains(w)) { pedeElemento = true; seg.remove(k); }
            else if (CMD_ALUNO.contains(w)) { pedeAluno = true; seg.remove(k); }
        }

        // ---- matéria dita no segmento ----
        boolean materiaNoSeg = false;
        int[] janela = new int[2];
        Store.Materia mat = detetarMateria(seg, c.materias, janela);
        if (mat != null) {
            for (int k = 0; k < janela[1]; k++) seg.remove(janela[0]);
            mudarMateria(c, mat.nome);
            materiaNoSeg = true;
        } else if (pedeMateria && temConteudo(seg)) {
            // "matéria natação …": matéria nova; o nome vai até ao primeiro aluno reconhecido
            int corte = seg.size();
            for (int k = 1; k < seg.size(); k++) {
                if (!c.alunos.isEmpty() && matchAluno(limparNome(seg.subList(k, k + 1)), c.alunos).score > 0) { corte = k; break; }
            }
            List<String> nome = new ArrayList<>();
            for (String w : seg.subList(0, corte)) if (!STOP_ELEM.contains(w) && numero(w) < 0) nome.add(w);
            if (!nome.isEmpty()) {
                String nova = frase(nome, r);
                Store.Materia m = new Store.Materia();
                m.nome = nova;
                c.materias.add(m);
                r.novos.add(new String[]{nova, null});
                mudarMateria(c, nova);
                materiaNoSeg = true;
            }
            seg = new ArrayList<>(seg.subList(corte, seg.size()));
        }
        if (!temConteudo(seg)) return;

        Item it = new Item();
        it.nota = nota;

        // ---- opções: só aluno, só elemento, aluno+elemento, elemento+aluno ----
        boolean comLista = !c.alunos.isEmpty();
        EMatch soElem = matchElementoGlobal(seg, c);
        Match soAluno = comLista && !pedeElemento ? matchAluno(limparNome(seg), c.alunos) : new Match();
        if (pedeAluno && soAluno.score == 0 && comLista) soAluno = matchAluno(limparNome(seg), c.alunos);

        int melhor = 0; String tipo = null;
        Match bA = null; EMatch bE = null;
        if (soAluno.score > melhor) { melhor = soAluno.score; tipo = "A"; bA = soAluno; }
        if (!pedeAluno && soElem.score > melhor) { melhor = soElem.score; tipo = "E"; bE = soElem; }
        for (int k = 1; k < seg.size(); k++) {
            List<String> esq = seg.subList(0, k), dir = seg.subList(k, seg.size());
            if (comLista) {
                Match a = matchAluno(limparNome(esq), c.alunos);
                EMatch e = matchElementoGlobal(dir, c);
                if (a.score > 0 && e.score > 0) {
                    int s = (a.score + e.score) / 2 + 10;
                    if (s > melhor) { melhor = s; tipo = "AE"; bA = a; bE = e; }
                }
                Match a2 = matchAluno(limparNome(dir), c.alunos);
                EMatch e2 = matchElementoGlobal(esq, c);
                if (a2.score > 0 && e2.score > 0) {
                    int s = (a2.score + e2.score) / 2 + 9;
                    if (s > melhor) { melhor = s; tipo = "EA"; bA = a2; bE = e2; }
                }
            }
        }

        // ---- elemento novo: matéria dita + aluno reconhecido + palavras que não são nenhum elemento ----
        if ((materiaNoSeg || c.materiaDita || pedeElemento) && comLista && (tipo == null || melhor < 40)) {
            for (int k = 1; k < seg.size(); k++) {
                List<String> esq = seg.subList(0, k), dir = seg.subList(k, seg.size());
                Match a = matchAluno(limparNome(esq), c.alunos);
                if (a.score > 0 && temConteudo(dir) && matchElementoGlobal(dir, c).score == 0) {
                    tipo = "AN"; bA = a; bE = novoElemento(dir, c); melhor = 40; break;
                }
                Match a2 = matchAluno(limparNome(dir), c.alunos);
                if (a2.score > 0 && temConteudo(esq) && matchElementoGlobal(esq, c).score == 0) {
                    tipo = "NA"; bA = a2; bE = novoElemento(esq, c); melhor = 40; break;
                }
            }
        }
        if (tipo == null && pedeElemento && temConteudo(seg) && c.materia != null) {
            tipo = "N"; bE = novoElemento(seg, c);
        }

        // ---- turma sem lista: os nomes ditos são alunos novos ----
        if (!comLista && (tipo == null || "E".equals(tipo) && soElem.score < 100)) {
            int ini = 0, corte = seg.size();
            EMatch e = null;
            // elemento no início ("pega Rui 4")
            for (int k = seg.size() - 1; k >= 1; k--) {
                EMatch em = matchElementoGlobal(seg.subList(0, k), c);
                if (em.score >= 50 && em.empates.size() == 1) { ini = k; e = em; break; }
            }
            // ou no fim ("Rui pega 4")
            if (e == null) for (int k = 1; k < seg.size(); k++) {
                EMatch em = matchElementoGlobal(seg.subList(k, seg.size()), c);
                if (em.score >= 50 && em.empates.size() == 1) { corte = k; e = em; break; }
            }
            List<String> nome = limparNome(seg.subList(ini, corte));
            if (!nome.isEmpty()) {
                it.aluno = frase(nome, r);
                it.alunoNovo = true;
                c.foco = it.aluno;
                if (e != null) aplicarElemento(it, e, c);
                else { it.materia = c.materia; it.elemento = c.elemento; }
                it.falado = it.aluno;
                if (it.elemento == null && it.problema == null) it.problema = "sem elemento";
                if (nota > 0) r.itens.add(it);
                return;
            }
        }

        if (tipo == null) {
            if (nota == 0) return; // palavras soltas sem nota: ignora
            it.falado = frase(limparNome(seg), r);
            if (it.falado.isEmpty()) it.falado = frase(seg, r);
            it.materia = c.materia;
            it.elemento = c.elemento;
            it.problema = "não reconhecido";
            r.itens.add(it);
            return;
        }

        it.falado = frase(seg, r);
        if (tipo.contains("A")) aplicarAluno(it, bA, c);
        if (tipo.contains("E") || tipo.contains("N")) aplicarElemento(it, bE, c);

        if (nota == 0) return; // só mudou o contexto

        if (!tipo.contains("A")) {
            if (c.foco == null) { if (it.problema == null) it.problema = "sem aluno"; }
            else it.aluno = c.foco;
        }
        if (!tipo.contains("E") && !tipo.contains("N")) {
            it.materia = c.materia;
            it.elemento = c.elemento;
            if (c.elemento == null && it.problema == null) it.problema = "sem elemento";
        }
        r.itens.add(it);
    }

    private static void mudarMateria(Ctx c, String nome) {
        if (nome.equals(c.materia)) { c.materiaDita = true; return; }
        c.materia = nome;
        c.materiaDita = true;
        Store.Materia m = achar(c.materias, nome);
        c.elemento = null;
        if (m != null && m.elementos.size() == 1) c.elemento = m.elementos.get(0);
    }

    private static EMatch novoElemento(List<String> palavras, Ctx c) {
        List<String> limpas = new ArrayList<>(palavras);
        while (!limpas.isEmpty() && STOP_ELEM.contains(limpas.get(0))) limpas.remove(0);
        while (!limpas.isEmpty() && STOP_ELEM.contains(limpas.get(limpas.size() - 1))) limpas.remove(limpas.size() - 1);
        String nome = frase(limpas, c.r);
        if (!nome.isEmpty()) nome = nome.substring(0, 1).toUpperCase(new Locale("pt", "PT")) + nome.substring(1).toLowerCase(new Locale("pt", "PT"));
        EMatch e = new EMatch();
        e.valor = nome;
        e.materia = c.materia;
        e.score = 40;
        e.novo = true;
        e.empates.add(nome);
        e.empMaterias.add(c.materia);
        Store.Materia m = achar(c.materias, c.materia);
        if (m != null && !nome.isEmpty()) {
            // a partir daqui, nesta frase, o elemento novo já existe
            Store.Materia copia = new Store.Materia(m.nome, m.area);
            copia.elementos.addAll(m.elementos);
            if (!copia.elementos.contains(nome)) copia.elementos.add(nome);
            c.materias.set(c.materias.indexOf(m), copia);
            c.r.novos.add(new String[]{m.nome, nome});
        }
        return e;
    }

    private static void aplicarAluno(Item it, Match a, Ctx c) {
        if (a.empates.size() > 1) {
            it.problema = "ambíguo";
            it.candidatos.addAll(a.empates);
        } else {
            it.aluno = a.valor;
            c.foco = a.valor;
        }
    }

    private static void aplicarElemento(Item it, EMatch e, Ctx c) {
        if (e.empates.size() > 1) {
            if (it.problema == null) it.problema = "elemento ambíguo";
            it.candElementos.addAll(e.empates);
            it.candMaterias.addAll(e.empMaterias);
            it.materia = c.materia;
        } else {
            it.elemento = e.valor;
            it.materia = e.materia;
            it.elementoNovo = e.novo;
            if (e.materia != null && !e.materia.equals(c.materia)) {
                c.materia = e.materia;
            }
            c.elemento = e.valor;
        }
    }

    // =================================================================== correspondências

    static class Match {
        String valor;
        int score;
        int usados;
        List<String> empates = new ArrayList<>();
    }

    static class EMatch extends Match {
        String materia;
        boolean novo;
        List<String> empMaterias = new ArrayList<>();
    }

    /** Procura o nome de uma matéria dentro do segmento; devolve-a e a posição/comprimento em janela. */
    static Store.Materia detetarMateria(List<String> seg, List<Store.Materia> ms, int[] janela) {
        Store.Materia best = null;
        int bestScore = 0;
        for (int i = 0; i < seg.size(); i++) {
            for (int L = 1; L <= 4 && i + L <= seg.size(); L++) {
                List<String> w = seg.subList(i, i + L);
                for (Store.Materia m : ms) {
                    List<String> mt = new ArrayList<>();
                    for (String x : tokens(m.nome)) if (!STOP_ELEM.contains(x)) mt.add(x);
                    if (mt.isEmpty()) continue;
                    // todas as palavras da janela têm de pertencer ao nome; pelo menos uma distintiva
                    boolean todas = true, distintiva = false;
                    int cobertas = 0;
                    for (String x : w) {
                        if (STOP_ELEM.contains(x)) continue;
                        boolean achou = false;
                        for (String y : mt) if (x.equals(y) || fon(x).equals(fon(y))) { achou = true; break; }
                        if (!achou) { todas = false; break; }
                        cobertas++;
                        if (!GENERICAS_MATERIA.contains(x)) distintiva = true;
                    }
                    if (!todas || !distintiva || cobertas == 0) continue;
                    if (STOP_ELEM.contains(w.get(0)) || STOP_ELEM.contains(w.get(L - 1))) continue;
                    int s = cobertas * 10 + (cobertas == mt.size() ? 5 : 0);
                    if (s > bestScore) { bestScore = s; best = m; janela[0] = i; janela[1] = L; }
                }
            }
        }
        return best;
    }

    static List<String> limparNome(List<String> toks) {
        List<String> nt = new ArrayList<>();
        for (String x : toks) {
            if (LIGACOES.contains(x)) { if (!nt.isEmpty()) nt.add(x); }
            else if (!IGNORAR_NOME.contains(x) && numero(x) < 0) nt.add(x);
        }
        while (!nt.isEmpty() && LIGACOES.contains(nt.get(nt.size() - 1))) nt.remove(nt.size() - 1);
        return nt;
    }

    static Match matchAluno(List<String> falado, List<String> alunos) {
        Match m = new Match();
        if (falado.isEmpty()) return m;
        for (String a : alunos) {
            int s = pontuar(falado, a);
            if (s > m.score) { m.score = s; m.valor = a; m.empates.clear(); m.empates.add(a); }
            else if (s == m.score && s > 0) m.empates.add(a);
        }
        return m;
    }

    /** Semelhança entre as palavras ditas e o nome de um elemento (0 = nada). */
    static int pontuarElemento(List<String> falado, String elemento) {
        List<String> f = new ArrayList<>();
        for (String x : falado) if (!STOP_ELEM.contains(x)) f.add(canon(x));
        List<String> et = new ArrayList<>();
        for (String x : tokens(elemento)) if (!STOP_ELEM.contains(x)) et.add(canon(x));
        if (f.isEmpty() || et.isEmpty()) return 0;
        boolean[] coberto = new boolean[et.size()];
        int m = 0, u = 0;
        for (String w : f) {
            boolean achou = false;
            for (int j = 0; j < et.size(); j++) {
                if (parecidoOuPrefixo(et.get(j), w)) { coberto[j] = true; achou = true; }
            }
            if (achou) m++; else u++;
        }
        if (m == 0 || u > m) return 0;
        int c = 0;
        for (boolean b : coberto) if (b) c++;
        if (c == et.size() && u == 0) return 100;
        int s = Math.round(95f * c / et.size()) - 50 * u;
        if (s <= 0) s = u == 0 ? 10 : 0;
        return s;
    }

    /** Procura o elemento em todas as matérias; a matéria em uso tem prioridade. */
    static EMatch matchElementoGlobal(List<String> falado, Ctx c) {
        // 1.º a matéria em uso. Se foi dita nesta frase, só ela conta (ex.: «voleibol … receção» nunca vai
        // para a «Receção» de Futebol). Se não foi dita, as outras matérias só contam quando a atual não tem
        // nenhum elemento parecido.
        Store.Materia atualM = achar(c.materias, c.materia);
        if (atualM != null) {
            EMatch so = melhorEm(falado, atualM);
            if (so.score > 0 || c.materiaDita) return so;
        }
        EMatch best = new EMatch();
        for (Store.Materia m : c.materias) {
            if (m == atualM) continue;
            for (String e : m.elementos) {
                int s = pontuarElemento(falado, e);
                if (s == 0) continue;
                if (s > best.score) {
                    best.score = s; best.valor = e; best.materia = m.nome;
                    best.empates.clear(); best.empMaterias.clear();
                    best.empates.add(e); best.empMaterias.add(m.nome);
                } else if (s == best.score) {
                    best.empates.add(e); best.empMaterias.add(m.nome);
                }
            }
        }
        return best;
    }

    private static EMatch melhorEm(List<String> falado, Store.Materia m) {
        EMatch best = new EMatch();
        {
            boolean atual = true;
            for (String e : m.elementos) {
                int s = pontuarElemento(falado, e);
                if (s == 0) continue;
                if (atual) s += 8;
                if (s > best.score) {
                    best.score = s; best.valor = e; best.materia = m.nome;
                    best.empates.clear(); best.empMaterias.clear();
                    best.empates.add(e); best.empMaterias.add(m.nome);
                } else if (s == best.score) {
                    best.empates.add(e); best.empMaterias.add(m.nome);
                }
            }
        }
        return best;
    }

    /** Pontuação de semelhança entre o nome falado e o nome do aluno na lista. */
    static int pontuar(List<String> falado, String aluno) {
        List<String> a = new ArrayList<>();
        for (String x : tokens(aluno)) if (!LIGACOES.contains(x)) a.add(x);
        List<String> f = new ArrayList<>();
        for (String x : falado) if (!LIGACOES.contains(x)) f.add(x);
        if (a.isEmpty() || f.isEmpty()) return 0;

        if (String.join(" ", a).equals(String.join(" ", f))) return 100;

        int j = 0, exatas = 0;
        boolean todas = true;
        for (String w : f) {
            boolean achou = false;
            while (j < a.size()) {
                String aw = a.get(j++);
                if (aw.equals(w)) { achou = true; exatas++; break; }
                if (parecido(aw, w)) { achou = true; break; }
            }
            if (!achou) { todas = false; break; }
        }
        if (!todas) return 0;
        if (f.size() == 1) {
            String w = f.get(0);
            if (a.get(0).equals(w)) return 60;
            if (parecido(a.get(0), w)) return 50;
            for (String aw : a) if (aw.equals(w)) return 40;
            return 30;
        }
        return 80 + f.size() * 2 + exatas;
    }

    static boolean parecidoOuPrefixo(String a, String b) {
        if (parecido(a, b)) return true;
        int min = Math.min(a.length(), b.length());
        if (min >= 4 && (a.startsWith(b) || b.startsWith(a))) return true;
        return a.length() == 1 && Character.isLetter(a.charAt(0)) && b.startsWith(a) && b.length() > 2;
    }

    static boolean parecido(String a, String b) {
        if (a.equals(b)) return true;
        String pa = fon(a), pb = fon(b);
        if (pa.equals(pb)) return true;
        int min = Math.min(pa.length(), pb.length());
        if (min < 4) return false;
        int lim = min >= 7 ? 2 : 1;
        return lev(pa, pb) <= lim;
    }

    /** Chave "fonética" simples para português. */
    static String fon(String s) {
        String x = s;
        if (x.length() > 1 && x.startsWith("h")) x = x.substring(1);
        x = x.replace("ph", "f").replace("th", "t").replace("y", "i").replace("w", "v")
                .replace("k", "c").replace("ss", "s").replace("ll", "l").replace("nn", "n")
                .replace("tt", "t").replace("z", "s").replace("qu", "c");
        return x;
    }

    static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int c = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c);
            }
            int[] tmp = prev; prev = cur; cur = tmp;
        }
        return prev[b.length()];
    }

    /** Junta as palavras repondo os acentos tal como vieram do reconhecimento de voz. */
    static String frase(List<String> toks, Result r) {
        List<String> out = new ArrayList<>();
        for (String x : toks) {
            String o = r == null ? null : r.orig.get(x);
            out.add(o != null ? o.toLowerCase(new Locale("pt", "PT")) : x);
        }
        return capitalizar(String.join(" ", out));
    }

    public static String capitalizar(String s) {
        StringBuilder b = new StringBuilder();
        for (String w : s.trim().split("\\s+")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            if (LIGACOES.contains(norm(w))) b.append(w);
            else b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return b.toString();
    }

    /** Escolhe, entre as hipóteses do reconhecimento de voz, a que melhor se ajusta. */
    public static Result melhor(List<String> hipoteses, List<String> alunos, List<Store.Materia> materias,
                                String materiaAtual, String elementoAtual, String focoAtual) {
        Result best = null;
        for (String h : hipoteses) {
            Result r = parse(h, alunos, materias, materiaAtual, elementoAtual, focoAtual);
            if (best == null || r.score() > best.score()) best = r;
        }
        return best;
    }
}
