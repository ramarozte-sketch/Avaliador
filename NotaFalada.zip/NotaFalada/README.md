# Nota Falada

Aplicação Android para avaliar Educação Física por voz. Diz-se o nome do aluno e a nota (1 a 5)
e a aplicação regista-a no elemento certo da matéria certa. No fim exporta um Excel com todas as turmas.

## Como ditar

Não é preciso escolher nada no ecrã: a matéria, o elemento e o aluno são reconhecidos no que se diz.

| O que diz | O que acontece |
|---|---|
| «Andebol, desmarcação: Jesus 4, Gabriel 2» | matéria e elemento ditos antes das notas |
| «Maria João 5, Tiago 3» | continua no último elemento dito |
| «pega: Jesus 3, Henrique 4» | muda de elemento |
| «Basquetebol, passe: Luana 4» | muda de matéria |
| «Jesus pega 3, remate em salto 5» | várias notas do mesmo aluno |
| «Voleibol, Jesus serviço por cima 4» | elemento que não estava na lista: é criado |
| «matéria natação, Jesus crol 4» | matéria nova |
| «anular» | anula o último registo |

Escala: 1 não faz · 2 faz mal · 3 executa com dificuldade · 4 executa · 5 executa muito bem.

As matérias e elementos vêm das fichas de autoavaliação do 7.º ano e podem ser editadas na aplicação.

## Excel

- **Resumo**: uma linha por turma.
- **Uma folha por turma**: alunos × elementos, agrupados por matéria, média por matéria,
  matérias atingidas, nível de Atividades Físicas no 1.º e 2.º semestre (tabela da ficha) e se tem 1 JDC + 1 GIN.
- **Registo**: todas as notas com data.
- **Critérios**: escala, tabela de níveis e a média mínima para uma matéria contar (3 por defeito, pode ser alterada).

## Compilar

O APK é compilado pelo GitHub Actions (`.github/workflows/build.yml`): ao enviar para o ramo `main`,
o APK fica em *Actions › última execução › Artifacts › NotaFalada-apk*.
Também abre diretamente no Android Studio.

## Atualizações diretas

Cada compilação no GitHub publica uma *Release* (`v<número>`) com o APK. A app procura uma versão nova
ao abrir (de 6 em 6 horas) ou no menu «Procurar atualizações», descarrega-a e instala-a por cima,
mantendo turmas e notas. O repositório tem de ser público. Todas as versões são assinadas com a mesma
chave (`app/notafalada.keystore`), por isso instalam-se umas por cima das outras.
