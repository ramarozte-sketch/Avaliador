# Nota Falada

Aplicação Android para avaliar Educação Física por voz. Diz-se o nome do aluno e a nota (1 a 5)
e a aplicação regista-a no elemento certo da matéria certa. No fim exporta um Excel com todas as turmas.

## Como ditar

| O que diz | O que acontece |
|---|---|
| «Jesus 4, Gabriel 2» | nota no elemento escolhido no ecrã |
| «Jesus desmarcação 4, pega 3, remate em salto 5» | várias notas do mesmo aluno |
| «aluno Jesus» … «pega 3, interceção 4» | fixa o aluno e avalia vários elementos |
| «elemento roda no plinto» | muda de elemento |
| «matéria basquetebol» | muda de matéria |
| «anular» | anula o último registo |

Escala: 1 não faz · 2 faz mal · 3 executa com dificuldade · 4 executa · 5 executa muito bem.

As matérias e elementos vêm das fichas de autoavaliação do 7.º ano e podem ser editadas na aplicação.

## Excel

- **Resumo**: uma linha por turma.
- **Uma folha por turma**: alunos × elementos, agrupados por matéria, média por matéria,
  matérias atingidas, nível de Atividades Físicas no 1.º e 2.º semestre (tabela da ficha) e se tem 1 JDC + 1 GIN.
- **Registo**: todas as notas com data.
- **Critérios**: escala, tabela de níveis e a média mínima para uma matéria contar (3 por defeito, pode ser alterada).

## Compilar

O APK é compilado pelo GitHub Actions (`.github/workflows/build.yml`): ao enviar para o ramo `main`,
o APK fica em *Actions › última execução › Artifacts › NotaFalada-apk*.
Também abre diretamente no Android Studio.
